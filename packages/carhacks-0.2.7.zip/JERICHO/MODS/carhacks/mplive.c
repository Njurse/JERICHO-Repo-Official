/* carhacks/mplive.c — the bridge to mp's live "Change car" row.
 *
 * mp's Multiplayer pause page has a Change car picker: pick a city, pick one of
 * that city's cars, and have it spawn as a replacement for the vehicle you are
 * driving. The picker itself lives in mp (it is mp's menu), but the two things it
 * cannot know on its own live here, and are asked for over custom JERICHO events
 * (jer_carquery.h -- a CORE contract header, so this mod builds whether or not
 * mp is installed -- is the one place the ids and structs are written down):
 *
 *   JER_CARQ_CITIES  "which cities can this session offer?"
 *   JER_CARQ_SLOTS   "which slots may a city be offered in, and what models?"
 *   JER_CARQ_LOAD    "make (city, model) available here"
 *   JER_CARQ_CHOSEN  "the switch happened (or did not): this is what we drive now"
 *
 * LOAD and CHOSEN are two events on purpose. The session is told what this machine drives
 * only after the switch SUCCEEDED (CHOSEN) - telling it at load time announced a car that
 * might then fail to build or never be driven, and every other machine built it anyway. And
 * CHOSEN is the moment the OLD car's slot can be offered back (net.c,
 * chkNetReleaseSlotIfUnused), which a load alone cannot know.
 *
 * THE LOAD HALF IS NOT NEW MACHINERY. It is the same sequence a mid-match peer
 * pick already goes through -- put the car in the session's canonical spare slot,
 * then chkImportHotLoad, which reads that city's data in, builds the slot's
 * geometry in the engine's own pool, applies its cosmetics and records its
 * texture pages. What this adds is the OPENING: mp asking for a car the player
 * chose, instead of one that arrived on the wire.
 *
 * Nothing here runs without a live mp session (mp only asks in one). The CITY list and
 * the CAR list are owned by CHK_HACK_UNLOCK_EXTRA -- the hack that fills the frontend
 * roster -- so the pause picker offers exactly what the frontend car screen offers, and a
 * pick is the request that imports the car whether or not the config-driven cross-city
 * hack (`cross_city_vehicles`) is on. With the roster hack itself off, no city list and no
 * slot list is answered and mp falls back to the session's own city and its frontend table,
 * which is the whole feature minus the extra vehicles -- exactly as it was.
 */
#include "driver2.h"

#include "jericho.h"
#include "jer_net.h"
#include "jer_console.h"	/* SLOT-TRACE headline lines also go to the on-screen console */

#include "cars.h"		/* gCarCleanModelPtr: is the built mesh really there */
#include "mission.h"
#include "players.h"		/* player[0].playerCarId: the local player's car_data entry */
#include "texture.h"		/* CarSlotResReport: the per-switch resource dump */

#include "carid.h"
#include "carimport.h"
#include "carhacks.h"
#include "net.h"
#include "mplive.h"

#include "jer_carquery.h"

static int ChkMpCities(void* userdata, void* args)
{
	JER_CARQ_CITIES_ARGS* a = (JER_CARQ_CITIES_ARGS*)args;
	int city;

	(void)userdata;

	if (a == NULL || a->cities == NULL || a->max <= 0)
		return JER_RESULT_CONTINUE;

	a->count = 0;

	/* The SAME hack that owns the frontend car list owns this answer (ChkMpSlots
	 * below), so the picker's city row can never disagree with the cars it offers.
	 *
	 * This used to be gated on CHK_HACK_CROSS_CITY, and that gate is what made the
	 * in-game picker show the session's own city and nothing else: with the
	 * config-driven hack off mp got count 0 ("nobody knows better") and offered one
	 * city, while the frontend menu -- which has no such gate, because a PICK is
	 * what imports the car -- still let the player browse every city. The two
	 * screens ask the same question and must answer the same way. Leaving count at
	 * 0 is still the answer "nobody knows better", and mp then offers the session's
	 * own city alone; that is now only reached when the roster hack itself is off. */
	if (!carhacks_enabled(CHK_HACK_UNLOCK_EXTRA))
		return JER_RESULT_CONTINUE;

	/* JERICHO: to the number of cities this install HAS, not the row capacity -
	 * a configured runtime bank that is not installed leaves a hole. */
	for (city = 0; city < chkCityCount() && a->count < a->max; city++)
	{
		/* Only cities this install can actually serve. A Driver 1 city with no data
		 * here is not offered at all, rather than offered with cars that cannot be
		 * built (chkCityAssetsPresent) - and that now covers the runtime banks too,
		 * since the answer comes from the engine's registry. */
		if (!chkCityAssetsPresent(city))
			continue;

		a->cities[a->count++] = city;
	}

	return JER_RESULT_CONTINUE;
}

static int ChkMpSlots(void* userdata, void* args)
{
	JER_CARQ_SLOTS_ARGS* a = (JER_CARQ_SLOTS_ARGS*)args;
	int slot;

	(void)userdata;

	if (a == NULL || a->slots == NULL || a->models == NULL || a->max <= 0)
		return JER_RESULT_CONTINUE;

	a->count = 0;

	/* The same hack that owns the frontend list owns this answer, so a session cannot be
	 * offered a wider list than the menus would show. Leaving count at 0 is the answer
	 * "nobody knows": mp then keeps its own list, which without this hack is what the
	 * frontend table says anyway. */
	if (!carhacks_enabled(CHK_HACK_UNLOCK_EXTRA))
		return JER_RESULT_CONTINUE;

	for (slot = 0; slot < CHK_CAR_SLOT_COUNT && a->count < a->max; slot++)
	{
		if (chkImportCanOffer(a->city, slot) != CHK_OFFER_OK)
			continue;

		a->slots[a->count] = slot;
		a->models[a->count] = chkImportSlotModel(a->city, slot);
		a->count++;
	}

	return JER_RESULT_CONTINUE;
}

static int ChkMpLoad(void* userdata, void* args)
{
	JER_CARQ_LOAD_ARGS* a = (JER_CARQ_LOAD_ARGS*)args;
	CHK_CAR_ID id;
	int slot, count = 0, fresh, reused = 0;
	CHK_CAR_ID was;
	int oldSlot = -1;

	(void)userdata;

	if (a == NULL)
		return JER_RESULT_CONTINUE;

	a->ok = 0;

	/* NO CONFIG GATE HERE. JER_CARQ_LOAD is only ever fired for a PLAYER'S EXPLICIT
	 * PICK -- mp's picker (mp_session.c) and the sandbox both ask for the car the
	 * player just chose -- and a pick is itself the request that imports it. That is
	 * the same rule the frontend car screen already follows: carhacks.c's
	 * ChkOnCarDataSource imports the menu's pick "even when the config-driven hack is
	 * off". Gating here on CHK_HACK_CROSS_CITY is what made a mid-match pick from
	 * another city silently refused while the frontend would have served it. */
	if (a->city < 0 || a->city >= CHK_CAR_CITY_COUNT || a->model < 0 || a->model > 12)
	{
		/* SAY SO. This used to read "a->city > 3" and return in silence, so a
		 * request for a Driver 1 car-data city was declined with no trace
		 * anywhere - mp asked, nothing happened, and the player saw only
		 * "not loaded here". It looked like nothing was ever requested. */
		printInfo("[carhacks/mp] change car: REFUSED %s model %d - city out of range "
			  "(0..%d)\n",
			  chkCityName(a->city), a->model, chkCityCount() - 1);
		return JER_RESULT_CONTINUE;
	}

	/* JERICHO: and a city whose car data is not HERE cannot be loaded from either -
	 * a Driver 1 city with no transplant, or a configured runtime bank that is not
	 * installed. Refusing loudly beats a pick that silently keeps the old car. */
	if (!chkCityAssetsPresent(a->city))
	{
		printInfo("[carhacks/mp] change car: REFUSED %s model %d - that city's car data is "
			  "not installed\n", chkCityName(a->city), a->model);
		return JER_RESULT_CONTINUE;
	}

	id = chkCarId(a->city, a->model);

	/* DIAGNOSTIC (CHK_DIAG_SLOT_TRACE): prove where the new car lands relative to the
	 * slot the local player is vacating. The premise this tests: a local change takes a
	 * FRESH spare (chkImportCanonicalSlot) while the old slot stays `used` until
	 * chkNetLocalSwitched releases it AFTER the adopt -- one change holds two slots. */
	if (getenv("CHK_DIAG_SLOT_TRACE") != NULL)
	{
		CHK_CAR_ID was = chkNetLocalCar();
		int oldSlot = chkCarIdIsSet(was) ? chkImportSlotOfCar(was) : -1;
		int s;

		jer_console_log("[carhacks/mp] change: %s model %d (was slot %d)",
			chkCityName(a->city), a->model, oldSlot);

		for (s = CHK_IMPORT_SPARE_FIRST; s < CHK_IMPORT_MAX_SLOTS; s++)
		{
			CHK_CAR_ID held = chkImportSlotId(s);
			int c = chkCarIdCity(held);
			int cars = chkImportCarsOnSlot(s, NULL);

			if (!chkImportIsSpareSlot(s))
				continue;

			jer_console_log("[carhacks/mp]   spare %d: held=%d %s model %d (cars on it %d)",
				s, chkImportSlotHeld(s),
				(c >= 0) ? chkCityName(c) : "-", chkCarIdModel(held), cars);
		}
	}

	/* A car the set already holds keeps the slot it is already in -- re-slotting
	 * it would move a car another player may be driving. Otherwise take the
	 * session's canonical spare for OUR player id: that is the slot every machine
	 * already agrees this player's cars live in. */
	slot = chkImportSlotForCar(a->city, a->model);
	fresh = (slot < 0);		/* this load claims the slot: a failure gives it back */

	if (slot < 0)
	{
		/* RETIRE THE OLD SLOT FIRST. The local player's own change vacates the slot
		 * they are in, so give it straight back BEFORE asking for a spare: the canonical
		 * mapping then sees that slot as free, and a change holds ONE slot instead of two
		 * (the old one kept until chkNetLocalSwitched released it AFTER the adopt). That
		 * two-slot transient is what made three seats changing at once run out of the
		 * four-slot import pool (7..10) with "no spare resident slot".
		 *
		 * Safe because it is synchronous and the slot is the player's own: chkImportReleaseSlot
		 * frees the mesh the player's car is drawn with, but the replacement is built into the
		 * set inside this SAME call (no frame, no draw, runs in between), and mp's adopt then
		 * re-points the car before the next render. The guard insists the sole car on the slot
		 * IS the local player's own car_data entry -- a shared car, a peer's remote copy, or a
		 * leftover civilian all fail it and the ordinary fresh-slot path runs instead. */
		was = chkNetLocalCar();
		oldSlot = chkCarIdIsSet(was) ? chkImportSlotOfCar(was) : -1;
		int localCar = player[0].playerCarId;
		int cars, first = -1;
		int retired = 0;

		cars = (oldSlot >= 0) ? chkImportCarsOnSlot(oldSlot, &first) : 0;

		if (chkImportIsSpareSlot(oldSlot) &&
			cars == 1 && first == localCar && localCar >= 0)
		{
			chkImportReleaseSlot(oldSlot);
			retired = 1;
		}

		/* REUSE the slot just vacated: the new car takes the old one's place in the
		 * SAME resident slot, so a change never accumulates a second slot. The canonical
		 * spare stays the fallback for a change that did not retire a slot (a shared car,
		 * a fresh pick with nothing to vacate, an on-foot pick). */
		if (retired && chkImportSlotFree(oldSlot))
		{
			slot = oldSlot;
			reused = 1;

			/* The old car IS released here (its mesh freed), just in place: the new car takes
			 * the slot in the same call. Log it like the other releases so the release audit -
			 * and the scenarios that read it - still see the old slot go. */
			printInfo("[carhacks] release: slot %d (%s model %d) released - reused in place (the local car changed into it)\n",
				oldSlot, chkCityName(chkCarIdCity(was)), chkCarIdModel(was));
		}
		else
			slot = chkImportCanonicalSlot(id, &count);
	}

	if (slot < 0)
	{
		printInfo("[carhacks/mp] change car: no spare resident slot for %s model %d (%d car(s) wanted)\n",
			chkCityName(a->city), a->model, count);
		return JER_RESULT_CONTINUE;
	}

	if (getenv("CHK_DIAG_SLOT_TRACE") != NULL)
	{
		jer_console_log("[carhacks/mp] -> slot %d (%s)", slot,
			reused ? "REUSED" : (fresh ? "fresh spare" : "kept"));
	}

	{
		/* A slot that ALREADY holds this car with its geometry built is not reloaded.
		 * Re-running the hot load while another live car still draws the slot (the
		 * car this player just got out of, parked on the same model) re-walks the
		 * palettes and rebuilds cosmetics for no reason - and it is exactly the
		 * window the release retry is trying to keep stable. */
		int already = (chkImportSlotForCar(a->city, a->model) == slot);

		chkImportSetSlot(slot, id);

		if (!already || !JerCarSlotUsable(slot))
			chkImportHotLoad(slot);
	}

	/* NOT advertised here (L1). The session is told this machine drives the car when mp
	 * reports that the switch happened (JER_CARQ_CHOSEN -> ChkMpChosen below): a load can
	 * still fail, or the switch can still not happen, and an advert sent now had every
	 * other machine build a car nobody was driving. */

	/* It counts as held only when the mesh is really there: mp is about to point a
	 * car at this slot, and a slot with no built geometry is a crash, not a
	 * cosmetic glitch (see mp's MpAdoptRemoteCar). */
	a->ok = (chkImportSlotForCar(a->city, a->model) == slot &&
		JerCarSlotUsable(slot)) ? 1 : 0;

	if (!a->ok)
	{
		printInfo("[carhacks/mp] change car: %s model %d could not be built into slot %d\n",
			chkCityName(a->city), a->model, slot);
		printInfo("[carhacks/mp]   detail: slotOfCar=%d usable=%d resident=%d srcCity=%d\n",
			chkImportSlotForCar(a->city, a->model),
			JerCarSlotUsable(slot),
			residentCarModels[slot],
			GetCarModelSourceCity(slot));

		/* If this change retired the old slot to reuse it, the old car's mesh is already
		 * gone and the replacement failed to build -- restore the old car rather than leave
		 * a held slot with no geometry. Best effort: the old car was working. */
		if (reused && chkCarIdIsSet(was) && oldSlot >= 0)
		{
			chkImportSetSlot(oldSlot, was);
			chkImportHotLoad(oldSlot);
			jer_console_log("[carhacks/mp]   restored the old car into slot %d (load failed)", oldSlot);
		}

		/* A slot this load claimed and could not fill: offer it straight back (the routine
		 * keeps it if somebody else turns out to name the car). */
		if (fresh)
			chkNetReleaseSlotIfUnused(slot, "load failed");
	}

	return JER_RESULT_CONTINUE;
}

/* mp says the Change car switch is over (JER_CARQ_CHOSEN; also fired when the player gets into
 * another car after being on foot).
 *
 *   changed = 1: the car on the road IS (city, model) now - city -1 for the level's own car.
 *                If that is not what we last told the session, move the identity (advert, our
 *                row, the host's table and set) and offer the old car's slot back.
 *   changed = 0: the switch did not happen. A car the load put in a slot for it is offered
 *                back (kept if anybody names it).
 *
 * Runs with or without the cross-city hack: the identity is the session's either way, and a
 * player switching between two of the level's own cars still has to be told to the others. */
static int ChkMpChosen(void* userdata, void* args)
{
	JER_CARQ_CHOSEN_ARGS* a = (JER_CARQ_CHOSEN_ARGS*)args;
	CHK_CAR_ID was, now;

	(void)userdata;

	if (a == NULL || a->model < 0 || a->model >= CHK_MODEL_LIMIT ||
	    a->city >= CHK_CAR_CITY_COUNT)
		return JER_RESULT_CONTINUE;

	now = chkCarId((a->city < 0) ? CHK_CITY_NATIVE : a->city, a->model);

	if (a->changed)
	{
		was = chkNetLocalCar();

		if (!chkCarIdEqual(was, now))
			chkNetLocalSwitched(was, now);
		else if (!chkImportChosenIsSet())
			chkImportSetChosen(now);	/* same car, but it is a choice now */

		/* the monitor, on every switch: what each slot holds and the pool's state, so a
		 * leak is a number that only goes one way */
		CarSlotResReport();
	}
	else
	{
		int slot = chkImportSlotOfCar(now);

		if (slot >= 0)
			chkNetReleaseSlotIfUnused(slot, "loaded for a change that did not happen");
	}

	return JER_RESULT_CONTINUE;
}

/* JER_CARQ_STANDIN: a resident slot holding the placeholder body, so mp can draw
 * it under a peer's car whose mesh is not built. It is DRAWN, never chosen: this
 * never touches the import set's chosen car and tells the session nothing. -1 means
 * no placeholder bank here, or no spare slot - mp falls back to the host car 1. */
static int ChkMpStandIn(void* userdata, void* args)
{
	JER_CARQ_STANDIN_ARGS* a = (JER_CARQ_STANDIN_ARGS*)args;
	CHK_CAR_ID id;
	int city, slot, count = 0;

	(void)userdata;

	if (a == NULL)
		return JER_RESULT_CONTINUE;

	a->slot = -1;

	city = chkPlaceholderCity();

	if (city < 0)
		return JER_RESULT_CONTINUE;

	/* Already held (the player picked it, or an earlier stand-in import)? */
	slot = chkImportSlotForCar(city, 4);

	if (slot < 0)
	{
		id = chkCarId(city, 4);
		slot = chkImportCanonicalSlot(id, &count);

		if (slot >= 0)
		{
			chkImportSetSlot(slot, id);
			chkImportHotLoad(slot);
		}
	}

	if (slot >= 0 && chkImportSlotForCar(city, 4) == slot && JerCarSlotUsable(slot))
		a->slot = slot;
	else
		printInfo("[carhacks/mp] stand-in: no resident slot for %s model 4 - mp draws the host car 1\n",
			chkCityName(city));

	return JER_RESULT_CONTINUE;
}

void chkMpLiveRegister(JERICHO_CONTEXT* ctx)
{
	ctx->jer_register_hook(ctx, JER_CARQ_CITIES, ChkMpCities, NULL, 0);
	ctx->jer_register_hook(ctx, JER_CARQ_SLOTS, ChkMpSlots, NULL, 0);
	ctx->jer_register_hook(ctx, JER_CARQ_LOAD, ChkMpLoad, NULL, 0);
	ctx->jer_register_hook(ctx, JER_CARQ_CHOSEN, ChkMpChosen, NULL, 0);
	ctx->jer_register_hook(ctx, JER_CARQ_STANDIN, ChkMpStandIn, NULL, 0);
}
