# MP_ADAPTER.md — carhacks over the JERICHO net bridge

How carhacks and the multiplayer module (`JERICHO/MODS/mp/`) fit together: the car
**identity** schema, the **channel** carhacks multiplexes over the bridge mp
exposes, the host-authority rule, and the mp-side deltas (**all three are landed**;
see "mp-side deltas" below).

## The problem this exists to solve

Two facts, both measured:

1. **mp carries a car as a bare MODEL NUMBER.** `MP_ROSTER_ENTRY.model` and
   `MP_CARSTATE_ENTRY.model` (`mp_proto.h`); the slot ↔ model resolution happens
   once, host-side, in `MpPlayerCarModel` using the session city
   (`mp_session.c:363-382`). `carSlot`/`carId` are documented as informational.
2. **A model number is not an identity.** Every city ships `CARMODEL_0..12` and the
   same number is a *different* vehicle in each (`VEHICLES.md`). So "Rio's model 9"
   is not expressible on mp's wire at all.

On top of that, while the *geometry* side is per-city (`gCarImports[CITY_COUNT]`,
one block per slot), the palette side is one bank of **three guest-city blocks**
(`civ_clut` rows 8..31, one 8-row block each). A session can mix as many source
cities as it can hold: the old "one guest city" gate is gone, so a set names whatever
it needs and the host's set is the one that counts (`mp_agree_imports`).

## The identity schema — `carid.h`

```
CHK_CAR_ID { unsigned char city; unsigned char model; }   city 0..3, or CHK_CITY_NATIVE (0xFF)
wire: [city][model]  (2 bytes)   CHK_CAR_WIRE_VERSION 1
```

`CHK_CITY_NATIVE` means "the level's own city" — no import, the stock path. The
wire form is versioned so a peer that does not know the version *refuses* rather
than guessing. `carid.h` is the single place that defines this; everything else
(`carimport.c`, `net.c`, `carselect.c`) is written against it.

## The connection schema — `net.{c,h}`

carhacks registers its own channel on the bridge mp already exposes
(`jer_net.h`), so **no mp change is needed to add a channel**:

| | |
|---|---|
| channel | `carhacks.car`, `JER_NET_RELIABLE` |
| inbound | `JER_EVENT_NET_RECV`, matched on the channel name; `peer` is the ORIGINAL sender |
| size | ≤ 27 bytes payload (the bridge's cap is 1024) |
| with no session | every call is a no-op (`jer_net_is_active() == 0`) |

`MP_CHANNEL` carries `fromPlayer`, and both relay paths (the in-game host and the
dedicated server) stamp it from the connection. That is what makes `peer` the real
sender on a client: it has one link, to the host/server, so the header is the only
place the original id can survive. It used to arrive as 0, and carhacks' own
`peer < 1` guard then discarded every relayed `PICK` — the dedicated-server symptom
where a peer's imported car was never folded in.

Message layout — `[wireVersion][tag]` then the payload:

```
REQ   (no payload)                     a joiner asks for the set and the car table
PICK  [city][model]                    "this is the car I am driving"
CARS  [count]                          the host's per-player car table, so EVERY
      count x [playerId][city][model]  machine knows who drives what
SET   [guestCity][count][version]      the host's agreed import set
      count x [slot][city][model]
```

`PICK` is no longer gated on the import agreement: identity is needed whether or
not the sets are agreed (only `SET` is). The host answers `REQ` with both.

## Drawing a peer's car

mp's carstate carries `cp->ap.model`, a **resident slot**, so the car one machine
draws for a peer is that peer's vehicle only when both machines' resident tables
agree. Two halves fix that; one limit is left.

**Identity (`CARS`).** Every machine needs to know what every player drives, and a
client's `PICK` only reaches the host - so the host relays the table (above).
`chkNetLocalCar()` reads the local player's car from the ENGINE (`player[0]
.playerCarId` → `car_data[].ap.model` = slot → `residentCarModels[slot]`, with
`GetCarModelSourceCity(slot)` as the city and `CHK_CITY_NATIVE` for the level's
own), so it reports the car actually being driven rather than a menu pick; a FRAME
watcher re-advertises whenever it changes, because mp settles `-mpcar` *after* the
session is up, **and again on a semi-random heartbeat while it does not change**
(45..150 frames). An event arms a short re-announce (1..30 frames) first: a car change,
a join, a peer's pick, a car-table/set arrival, or `Reload all cars`. That second part
is not politeness: this advert is the session's only one-shot announcement - every
other direction is re-sent by the host on a timer - so without it a lost advert, a late
joiner, or an import it triggered that failed leaves the host drawing that player's old
car for the rest of the match. The jitter also keeps every machine from transmitting on
the same beat. `CHK_DROP_ADVERT=<n>` throws the first `n` adverts away so that failure
is reachable in a test.
`chkNetPeerCar(player, out)` / `chkNetPeerCount()` read it back.

**The correction (`JER_EVENT_CAR_PEER_DRAW`).** mp fires this as it applies a
remote car's state (declared in `jer_events.h`, so the engine stays generic).
carhacks answers whether this machine really holds that player's vehicle, and when
it does not it names the palette the car *actually drawn here* supports - 0, the
base colours every resident model has - and mp uses that instead of the owner's
index. A car that IS the owner's is left alone, so mp's owner-authoritative colour
still works. Measured over the divergent pair:

```
[carhacks/net] peer 1 drives RIO model 9, but this machine draws HAVANA model 8
               in slot 5 - using that car's own colours (theirs is not loaded here)
[mp] palette: player 1 reports 2, drawn as 0 (corrected: not their car here)
```

Carrying a nonzero owner palette needs a lever: a headless run has no colour
picker, so the local car always comes out palette 0 and none of this would ever
fire. `CHK_FORCE_PLAYER_PALETTE=<n>` sets it, the way `CHK_FORCE_CAR` drives the
menu.

**The set holds as many cities as it names.** `chkNetFoldPeerCars()` folds every
peer's car into the level's import set, so a peer is drawn as their own vehicle.
The geometry side holds several cities at once (`gCarImports[CITY_COUNT]`, one source city
per slot) and the palette bank holds three (`civ_clut` rows 8..31) - and the set
itself now names as many source cities as it has slots: the one-guest-city gate is
gone. A car from the level's own city is skipped - it needs no import, and
skipping it keeps an identity that has not settled yet from claiming a spare slot
with the level's own model 0.

**Why that is not the whole fix.** A level reads its car files ONCE
(`JER_EVENT_CAR_DATA_SOURCE` → `ProcessCarModelLump`), and a joiner's car is only
known after it joins - so on the machine that loaded first, a peer's car can never
be in the set in time, whatever city it is from; loading it afterwards is `JerHotLoadCarModel`,
`JerHotLoadCarCosmetics` and `JerHotLoadCarTpages` (all `✓` below).

### The resource lifecycle: what each join/leave event must load and unload

Every resource a carhacks import holds is attached to a RESIDENT SLOT (the manifest above
says which), so every session event is really a question about slots. This is the contract
to monitor; `CarSlotResReport()` prints it at the moment the session ends, after every
release and after every car switch, and the `cross-city: slot N holds ...` lines print it
whenever the pin walk finishes.

Both columns exist now. The release side is `JerReleaseCarSlot(slot)` - the pins and their
lower-half pool pages, the baked 110..127 index each of the slot's sets holds (and the
reservation that keeps it out of the next import), the geometry block, the manifest entry -
plus the module's half (`chkImportReleaseSlot`), which clears the set entry, the slot's
entry in `residentCarModels[]` and its source city. Leave either half and the slot still
looks taken (`chkImportSlotFree` checks all of it), so the next joiner is refused a spare
that is really free. Neither half is called directly any more: every unload below goes
through ONE release routine, which decides WHETHER the slot may go (see "Releasing a slot"
below).

| event | what must LOAD | what must UNLOAD | today |
|---|---|---|---|
| **local player picks** (before the level) | the pick's city data (`InitCarImport`), its palette block, its page lists; the pick's slot is canonical | the PREVIOUS pick's slot, if it was a different car | load ✓, unload ✓ by the level load, which rebuilds the whole set (row below). `chkImportApplyPick` itself releases nothing |
| **local player changes car mid-match** (pause menu `Change car`) | the new city's data; a hot load into a slot (geometry, cosmetics, pages, rows) | the old car's slot, once nobody names it and no car is on it | load ✓ (`JER_CARQ_LOAD`), unload ✓ (`JER_CARQ_CHOSEN` -> `chkNetLocalSwitched` -> the release routine, "we changed car"). Before #14 nothing was released here, so every switch leaked a spare |
| **local player gets back into a car on foot** | nothing (the car is already in the world) | the slot of the car they were in, if nobody else names it | ✓ (`MpFollowLocalCar` fires `JER_CARQ_CHOSEN` on the re-entry; same path as the row above). A direct car-to-car move without leaving the car does not fire it |
| **peer joins, before the match starts** | the peer's city at the next level load (through the set) | nothing | ✓ |
| **peer joins, match in progress** (the catch-up) | the peer's city read mid-level + a hot load into a slot | nothing (a new slot) | ✓ |
| **peer changes car mid-match** (to an import OR to a domestic car) | the new car, as a peer pick (hot load) | the peer's old slot | ✓ (`chkNetUnbindChangedPeers`, from the fold and the `PICK` handler: a peer whose recorded slot no longer matches its pick is unbound and the release routine runs, "player P changed car". This includes the import -> domestic pick that the fold skips with `continue`) |
| **the host changes car mid-match** | on the host: as the local row above; on a client: the host's new car (#13: not imported mid-match yet) | on a client: the host's old slot, if this client held it in a spare | ✓ for the unload (the client records the host's spare slot when it already holds that car, and the fold's unbind releases it). The load half is #13 |
| **peer leaves** | nothing | that peer's slot | ✓ (`chkNetReleaseDeparted` -> the release routine, "player P left": released, or KEPT while another player still names the car, or DEFERRED while a car is still on the slot. The car table shows a departure, and the roster catches it when the table cannot - the HOST's own case, `jer_net_player_present`) |
| **local player leaves the session** (back to the frontend) | nothing | EVERYTHING cross-city: the set, the picks, the pins, the pool pages, the blocks, the page lists, the deferred palette lumps | ✓ (`chkImportReleaseAll` -> `JerReleaseAllCrossCity` + `JerReleaseCarImport`) |
| **a new level loads** (restart, city change, rejoin) | the whole set from scratch | the previous level's state | ✓ (`InitCarImport` -> `CarImportResetState`; `chkNetOnLevelReset` drops the peer slot records and any pending release) |

The lifecycle rule the table encodes:

  a slot's resources are the LOAD of the event that created it, and are given back by the
  UNLOAD of the event that removed it - either that peer leaving, that pick being replaced,
  the local player leaving the session, or the level going away.

The monitor criteria, in the same terms: after a leave, `CarSlotResReport()` must show
**no slot holding pins or geometry that no player is driving**; a slot still listed is a
leak, and the count should return to what it was before the peer joined. `CarSlotResReport()`
runs after the release now, so a clean leave prints nothing after it. After a switch, the
`cross-city: pool` line must not keep growing: pins, pages and CLUT rows used should come
back to the same numbers once the old car is released.

### Releasing a slot

Every unload in the table goes through one routine, `chkNetReleaseSlotIfUnused(slot, why)`
(`net.c`; the verdict itself is the pure `chkReleaseVerdict` in `slotrelease.h`). It is
called for a peer leaving, a peer changing car, the local player changing car (picker or
re-entry on foot), and a hot load that failed. The rule:

  a spare slot is FREED only when no player's carhacks identity still names the car on it
  (the local car, the local pick, every peer's pick - `chkNetCarWantedBy`) AND no car in
  `car_data[]` is still on the slot (`chkImportCarsOnSlot`: `controlType != CONTROL_TYPE_NONE`
  and `ap.model == slot`).

The verdict is one of: **released**; **kept** (somebody still names the car - nothing is
pending, because whoever names it will free it when they move on); **deferred** (nobody
names it, but a car is still on the slot - a peer's copy that has not been re-modelled yet,
a parked car, our own car on the frame of the swap). A deferred slot is retried every frame
(`chkNetRetryPendingReleases`, from `chkNetOnFrame`) until it can go or something names the
car again. Only spare slots (`CHK_IMPORT_SPARE_FIRST` and up) are ever released; the
level's own and the config's import slots are not.

One log line per decision, and one per change of a retried decision (not per frame):

```
[carhacks] release: slot 5 (VEGAS model 1) released - nobody names it and no car is on it (we changed car)
[carhacks] release: slot 5 (VEGAS model 1) kept - still named by player 1 (player 2 left)
[carhacks] release: slot 5 (VEGAS model 1) deferred - car 3 still on it (1 car) (player 1 changed car); retrying each frame
```

A release frees both halves. The module's (`chkImportReleaseSlot`) clears the set entry
and the source city and writes the level's own model back into `residentCarModels[slot]`,
or **-1** for a spare the level never had (0 is a real model number; writing it made a
freed spare look like it held model 0). The engine's (`JerReleaseCarSlot`) is safe on
its own terms, because a pinned page can be shared:

- each pin carries a bitmask of the slots that own it (`sPinOwners`); the slot is taken out
  of every mask, and only pins whose mask reaches 0 give back their pool page;
- the pin's world texture slot is a separate field (`sPinTexSlot`, -1 = in the pool) - the
  old `sPinSlot` meant both, so a release could not tell an owner from a placement;
- a set's baked 110..127 index and its reservation are given back only when no remaining
  pin pages it in and no other imported slot names the set (`CarRemapReleasable`);
- each pin's CLUT band (`sPinClutY`/`sPinClutRows`, whole rows at x=960) goes onto a free
  list, merged with its neighbours; a later pin takes a band from that list before the
  watermark moves, so switching back and forth does not move the watermark;
- level-built geometry is un-pointed (`JerReleaseCarGeometry`), hot-loaded geometry freed.

It logs `cross-city: released slot N - P pool page(s), R CLUT row(s), I baked index(es) given
back; K page(s) kept (another car still names them)`, then `CarSlotResReport()` runs.

**Not reclaimed (TODO).** A guest CITY's palette table (`cars.c`) and its `civ_clut` block
are per city, not per slot, so no single slot's release frees them; they stay until the
level goes. The `cross-city: pool` summary prints the CLUT watermark and the free list,
so their growth is visible.

**Limitation.** If every spare is in use, a peer who switches cars cannot have the new car
imported here (`no spare resident slot`). Its old car keeps drawing on the old slot, so
that slot stays deferred until the peer's car moves off it (or the peer leaves). Nothing
leaks, but the new car is not drawn until a spare frees up.

### The hotload (DONE: geometry, cosmetics, pages, catch-up)

A car folded in after the level loaded gets **all four** things a level-load import gets,
and a joiner is given them too:

| what | how |
|---|---|
| geometry | `JerHotLoadCarModel(slot)` (`models.c`) - the same three `GetCarModel` calls the per-slot build makes, into a pool this module owns (it cannot use `malloctab`: that is the level's heap, rewound per load). Refuses rather than half-building. |
| source city | `JerSetCarModelSource(slot, city)` (`mission.c`) - the per-slot source array was writable only from `JER_EVENT_CAR_DATA_SOURCE`, before the models are built. |
| cosmetics | `JerHotLoadCarCosmetics(slot)` (`cosmetic.c`) - `car_cosmetics[slot]` + `FixCarCos`, which is where the WHEELS (`wheelSize`/`wheelDisp`), the SHADOW corners (`cPoints`), the collision box and the COG come from. Without it a hot-loaded car wore the host LEVEL's wheels and handling. |
| texture pages + rows | `JerHotLoadCarTpages()` (`texture.c`) - re-runs the level-load walk (`LoadImportedTPages`), which is what records a car's pages (`CarPinRecord`); `CarImportPin` then places them and uploads their CLUT rows. Without it the model's polys read the local city's pages: "the cosmetic file loaded but the model retained the local city's materials". `CarPinRecord` is idempotent now, so a re-walk leaves the cars already pinned alone. |
| the rebuild | mp's swap (`cp->ap.carCos = &car_cosmetics[slot]` + `CreateDentableCar`) for a car already on the road, logged. A hot-loaded car's cosmetics are in place before it can resolve the slot, so the rebuild takes the right ones. |

The trigger is carhacks' `chkImportHotLoad(slot)`, called from the fold **and** - the
catch-up - from the two places a joiner learns who drives what: the `CHK_NET_CARS`
handler (the per-player table) and `chkNetApplyAgreedSet` (the host's set). A joiner's
level loaded before any of those cars existed in it, which is what joining a match in
progress means; without the catch-up it drew them as the level's own car of that number
("player 2 saw the imported Vegas truck, but player 3 didn't see player 2's car").

The slot each car takes is canonical (`chkImportCanonicalSlot`, `carimport.c`): the
lowest owning player id first, taking the i-th spare the LEVEL leaves free. Ordering by
player id is append-only, so a joiner cannot displace a car already in a slot, and the
same `(city, model) -> slot` holds on every machine - which is what makes the pages and
rows that were baked against that slot agree.

**Still open, and they are palette/VRAM placement rather than the load:**
- On the HOST, a second imported city's textures and colours come out wrong while the
  first is right ("the vegas car imported proper but not the havana one's textures and
  colors"). Two guest cities' pages and CLUT rows are placed in the same pool and bank,
  so this is a collision between guests, not a missing import.
- The machine that imported a car gets its SCENERY/building textures contaminated, and
  its car palettes were "still messed up" until the band fix. The contamination is the
  pin's own wording - "paged in at draw time, **evicting the world if needed**" - and an
  import has no business taking a world page: the lower-half pool is where it belongs.
  Worth testing with **a different palette number per test player** (within the vehicle's
  own palette count) so a mix-up is unambiguous.
- **CLOSED: an access violation when a player leaves a session and rejoins picking a car
  from a DIFFERENT city than before.** Returning to the frontend means there is no map, and
the cross-city state used to be reset only when a level LOADED (`InitCarImport` ->
`CarImportResetState`), so the frontend ran with the last map's cross-city state in place:
the deferred palette lumps (`sImpPalLump[]`/`sImpPalSize[]`) and the parsed page lists
(`gCarImportPerms[]`/`gCarImportSpecs[]`/`gCarImportTexParsed[]`) are pointers INTO the
import buffers and were only cleared by the next level's load, and the import buffers
themselves were freed there too. The fix is the cleanup the report asked for:
`chkImportReleaseAll()` on the session ending -> `JerReleaseAllCrossCity()` (every slot,
then `CarImportResetState`, `CarImportPaletteReset`, the page lists) and
`JerReleaseCarImport()` (the buffers and the hot-load pool). Verified with `MP_TEST_LEAVE`:
the leaver's own log shows the session ending, every slot released, the buffers freed and
`released everything - no map is loaded`, with no dump.
- The dented variant's textures come out "a little messed up" on an imported car: the
  damaged model is built (`gCarDamModelPtr`) but its page/row needs are the same walk's,
  so a damaged-only set is the place to look.
- The palette bank holds three guest cities (`CIV_CLUT_ROWS 32` / `CIV_CLUT_IMPORT_ROW 8`
  / `CIV_CLUT_BLOCK_ROWS 8`), and the tpage remap indices are `110..127` (18) - both are
  real ceilings, and both are where a multi-city session runs out first.

**Kept as the record of the measurement that started this.** It was taken BEFORE
the per-city import block landed, when a second city's geometry really was absent,
and with the one-source-city gate opened by hand (a measurement lever that has
since been deleted along with the gate itself) so the ENGINE finally saw a set
naming two cities:

```
[carhacks] import: slot 5 <- model 8 from HAVANA
[carhacks] import: slot 6 <- model 9 from RIO          <- the lever let this in
cross-city: car data from HAVANA (131412 bytes of models, 14792 of car palettes)
cross-city: HAVANA car palettes applied to civ_clut rows 8..15
cross-city: slot 5 geometry from HAVANA model 8
                                                       <- no "car data from RIO",
                                                          and no "slot 6 geometry"
[pair] verdict: PASS   (no crash, no dump, 0 dumps)
```

The per-slot source city is real, and each slot now builds from its own city
(`ProcessCarModelLump`, `models.c:764-783`). That is what the hotload actually
has to do:

1. The identity is already there: `chkNetPeerCar()` says which (city, model) each
   peer drives, and `chkNetFoldPeerCars()` is already the place a car joins the set.
2. Read the second city's **model + page + palette** lumps at runtime (the parts
   `ProcessCarModelLump` does at level start), then pin them with `CarImportPin`
   and upload the palette rows - the single-city assumption is precisely in the
   palette upload, which keys off `GetCarImportCity()` (`cars.c:1623`).
3. Fit them in the measured budget: ~130 KB of models plus ~15 KB of car palettes
   per city (the `cross-city: car data from …` lines, `CROSS_CITY.md`), with the
   CLUT column ~89-95% committed and the level font owning rows 466..511
   (`carhacks/docs/VRAM.md`; the level's own slot walk already reaches y=436). Refuse
   rather than corrupt when it does not fit.
4. Rebuild the peer's car object with the same call the mesh fix uses
   (`CreateDentableCar`, mp's `MpAdoptRemoteCar`). `ChkOnCarPeerDraw` then stops
   correcting that player, because the car drawn IS theirs.

### Retrying a load that could not happen yet (DONE)

A fold can fail for a moment and succeed a moment later, and until this landed a
failure was **final**: the peer stayed drawn as this level's own car of the same
number for the rest of the match, and the only thing that ever tried again was
the peer's own pick advert seconds later, if it arrived at all. The two reasons a
fold fails are both transient -

- the canonical spare slot is **busy**: a slot whose last car is still drawn on it
  is *deferred* by the release routine (`chkNetRetryPendingReleases`), which frees
  it a frame or two later; and
- the build did **not fit yet**: `JerHotLoadCarModel` refuses when the hot-load
  blocks (`JER_HOT_CAR_BLOCKS`) are all in use - they come back through
  `JerReleaseCarGeometry` when a car changes away.

So `net.c` now keeps a small retry per player (`gChkNetLoadRetry*`,
`chkNetLoadRetryArm`/`Clear`) and, every frame, re-runs the fold when a waiting
car is due (`chkNetRetryPendingLoads`, from `chkNetOnFrame`, next to the release
retry). The delay is `CHK_NET_LOAD_RETRY_FRAMES` (10 frames, ~0.4 s - one beat,
enough for the deferred release to land and not so eager that it walks the set
every frame), and the wait is bounded at `CHK_NET_LOAD_RETRY_MAX` (20 attempts,
~8 s) so a slot held for a reason that outlives it still ends: the refusal is then
logged **once** as final. The wait clears itself the moment the car is really
there (`JerCarSlotUsable`), so a fold that has nothing left to do says nothing.

It heals both failure shapes above - the slot-busy case (the `no spare resident
slot is free` refusal) and the build case (the car is in the set for a slot but
`JerCarSlotUsable` is still false, caught in the fold's "already in the set"
branch) - and it resets on a new pick, a level reset and a session end, and is
dropped for a player who leaves (`gChkNetPeerPickSet`).

**Proof, made deterministic with a lever.** A transient refusal is otherwise only
reachable by luck (a slot has to be busy at the exact moment a pick arrives), so
`CHK_REFUSE_LOAD=<n>` holds back the first *n* fold attempts for every player, the
way `CHK_DROP_ADVERT` does for a lost message. With `CHK_REFUSE_LOAD=3` on a host
in a two-seat run:

```
[carhacks/net] CHK_REFUSE_LOAD: refusing player 1's car (attempt 1 of 3) to exercise the retry
[error] [carhacks/net] player 1 wants VEGAS model 10, but every spare resident slot is busy right now - retrying
[carhacks/net] CHK_REFUSE_LOAD: refusing player 1's car (attempt 2 of 3) ...
[carhacks/net] CHK_REFUSE_LOAD: refusing player 1's car (attempt 3 of 3) ...
[carhacks/net] player 1's car (VEGAS model 10) -> resident slot 7
[carhacks/net] peer 1 drives VEGAS model 10 and this machine draws exactly that (slot 7) - their own colours
```

and with `CHK_REFUSE_LOAD` larger than the budget, exactly **one** `no spare
resident slot came free - not importing it` (the give-up) and exactly **one**
`... is busy right now - retrying` (the first attempt) - a retry is not news, so it
does not spam the screen or the log. The terminal phrase is kept distinct from the
wait on purpose: `mp_tries` T2 forbids it (a slot-reusing switch must never exhaust
the spares), so a transient that heals must not wear it. At the car-stress cadence
(~3 changes/s) the churn
supersedes most picks before a slot frees, which is the mechanism working rather
than failing; at a human's rate the beat is what turns a refused pick into a car.

## Authority and lifecycle

The **host is authoritative**, so every machine draws the same cars. That is no
longer a limit being worked around: a set may name as many source cities as it has
slots (see `chkImportSetSlot`), and the host's set simply wins. `mp_agree_imports = 0` (`carhacks.ini`) turns the whole agreement off —
every machine keeps its own set, which is what a session where the players
deliberately want different cars needs, and what the three-city stress test below
uses.

1. **Session start** (`JER_EVENT_FRAME` sees `jer_net_is_active()` become true):
   the host publishes what it has (possibly nothing yet), a client sends `REQ`.
2. **The set is built** — each machine's `JER_EVENT_CAR_DATA_SOURCE` builds its
   level's import set. The host then **publishes** it (`chkNetNotifySetBuilt`).
   Publishing off `JER_EVENT_LEVEL_LAUNCH` was wrong and is called out in the
   source: that event fires *before* the level's car data is set up, so it sent an
   empty set.
3. **A `PICK`** from a peer is folded into the host's own set (the claim takes a
   spare resident slot, so the host **loads** what its clients asked to drive) and
   the host re-publishes.
4. **`REQ`** from a joiner is answered by the host re-publishing.
5. **A client adopts** the received `SET`: while one is in force its own
   `carhacks.ini` stands down. On the **host** the config is the authority and is
   always read — the stand-down rule must never apply to the authority (that was a
   real bug this caught).

Because the engine applies an import set once per level, **an agreed set only takes
effect at a level LOAD**. A client that has not received one before its own load
falls back to its own config for that level and adopts the host's at the next. A
mid-level change therefore cannot move anyone's car; it takes effect next level.

## Slot ownership — the contract with mp

`carhacks` writes `modelSource[slot]` (which city a resident slot reads from) and
`models[slot]` only for the entries it owns:

| slots | owner | what |
|---|---|---|
| the config `import = slot:city:model` slots | carhacks | that slot's model + source city |
| the pick's / a peer's spare slot (5, then 6) | carhacks | that foreign car |
| 5, 6 when mp seats extra players | **mp** | `gMpExtraModel`, `modelSource = -1` |

**Ownership, resolved.** Both used to use spare slots 5/6 and both answered
`JER_EVENT_CAR_DATA_SOURCE` at priority 0, so one could silently overwrite the other.
Both halves are fixed: carhacks now answers that event at priority 10 — i.e. AFTER mp
— and its automatic slot choosers (`chkImportApplyPick`, `chkNetFoldPeerCars`) skip
any resident slot that already holds a model (`chkImportSlotFree`, fed the engine's
live `models[]` through `chkImportSetEngineModels`). mp's reserved slots win
deterministically, and so does any other module's claim.

### The car LIST mp's picker reads — owned by this module now (DONE)

`mp.c`'s pause picker, this module's own car screen and the stock screen all read the
engine's `CarAvailability[4][10]`. The stock version starts as `{1,1,1,1,0,...}` for EVERY
city and lifts the tail slots only for a finished game, a cheat in single player (cleared
outright in multiplayer), or `unlock_extra_vehicles` — so the picker offered four cars a
city and nothing else, and a `car_list` remap landed in slots that stayed dark. This module
now writes every city's row from one query (`chkImportCanOffer`) and tells the engine it
owns the list (`JER_EVENT_CAR_AVAILABILITY.own_list`), which stops the engine's own gates
from overwriting it a line later. Measured: **9 of 10 slots per city**, the exception being
slot 4, which names no car.

Two consequences for mp:

- a peer can now pick a car this machine has never seen, so the pick-time import path is
  reached MORE often, not less — which is exactly the path the hotload section and the
  own-city/slot-pool notes below are about;
- the list is claimed only when this module's own car-select screen is on, because claiming
  it means the PICKS are ours to serve (a stock Select records nothing for us). With the
  stock screen in use the table is left to the engine's gates and mp's picker sees the old
  four-cars-a-city list.

## mp-side deltas — all three are DONE

1. **Carry the city. DONE** (`MP_PROTO_VERSION` 6). `MP_ROSTER_ENTRY.modelCity` and
   `MP_CARSTATE_ENTRY.modelCity` carry the city (`0xFF` = the session city), and the
   carstate's `model` is the model NUMBER, not a slot. `MpResidentSlotForCar` resolves
   the pair to the receiver's OWN slot, and `-mpcar [city:]model` names one.
2. **Reserved slots. DONE**, by observation rather than a query: carhacks answers the
   source event after mp and skips slots the engine already holds a model in (above).
   It now also skips them when the host PUBLISHES its set (a peer's PICK, a session
   start), which is outside that event: the resident list is COPIED out of the hook and
   answered from the copy, because the publish-time fold used to take mp's slot 5.
3. **Offer the roster in-session. DONE** (`carselect.c`). The menu arms inside a live
   session (the single-player gates apply only outside one) and `Ride` fires
   `JER_EVENT_MP_FRONTEND`/`JER_MP_FE_START` — the event the stock frontend raises on
   `BTN_START_GAME` — so **mp** launches and the pick travels in `wantedCar[0]` as
   before. See `CARSELECT.md`. Still open: a peer whose car this machine cannot build
   is corrected rather than loaded (the hotload below); the set is applied once per
   level, so it takes effect at the next load.

### An own-city car the level does not pool

`chkImportApplyPick` and `chkNetFoldPeerCars` used to skip a car from the level's own
city on the assumption that "the level already lists its own city's vehicles". A level
pools only the models its OWN list names — Rio's model 12 (the special) is in Rio's
files and in no Rio take-a-ride level — so the host was left with nothing to build the
peer's car from and `InitPlayer` fell back to resident slot 0: the level's FIRST car,
which is "I picked car 12 and spawned as car 1". Both callers now ask
`chkImportLevelHoldsModel` and import the car from its own city's files when the pool
provably does not hold it.

That helper answers in THREE values (held / provably not / cannot tell), and the third
is load-bearing: the fold also runs from the publish path outside the hook. Reading
"cannot tell" as "not held" there folded an own-city car the level already had, and an
own-city "guest" writes the level's own city's car palettes into a guest `civ_clut`
block — every colour in the session goes wrong. Callers that would import on a "no"
treat "cannot tell" as "leave it alone".

### The spare-slot pool

`CHK_IMPORT_MAX_SLOTS` is 11 (resident slots 0..10; 11 is the engine's
`SPECIAL_CAR_SLOT`), not 8: with the old cap the search had 5, 6, 7, mp claims two of
those for extra players, and a second cross-city pick was refused with "no spare
resident slot is free". Each distinct source city still needs a palette block and the
bank holds three (`civ_clut` rows 8..31), which is the real limit on how many CITIES a
session can mix — see `docs/VRAM.md`.

**How many spares are actually usable: four** (resident 7..10). The pool runs 5..10,
mp claims 5 and 6 for extra players, and that leaves 7, 8, 9 and 10 for imports — so
"6 spares" is the size of the pool, not the room in it. (A configured `import=` or
`traffic_slot` that names a non-spare slot, e.g. `import = 4:3:2`, does not come out of
this; it takes a level slot that was not a spare anyway.)

Measured by cycling cars, because the arithmetic matters for whether a switch can be
served: **13 switches on the host and 10 on the client, across all four cities, every one
served — and the two spares used alternate.** A player's successive cars reuse the same
two resident slots (7 and 8, alternating), the one they leave is released each time
(`released resident slot N - free for the next car`), and the pool stays at 2 pins:

```
[mp] car status: driving model 2 (resident 8, source HAVANA); mesh loaded
[carhacks] released resident slot 7 - free for the next car
```

That is what makes a long cycle survive: a mid-match change frees the car being replaced
and re-occupies a slot it already holds, rather than taking a new spare per pick.

## What is verified today

### The channel, over a real session

Over a real two-instance session on one machine (`JERICHO/MODS/mp/tools/mp_pair.bat`,
host + joiner, `carhacks.ini` = `cross_city_vehicles = 1` / `import = 5:0:8`, host
level RIO):

```
host    [carhacks/net] published the agreed set: guest city CHICAGO, 1 entry
client  [carhacks/net] asked the host for the agreed set
client  [carhacks/net] the host's agreed set arrived: guest city CHICAGO, 1 entry (applied at the next level)
```

and, with no session at all, a plain single-player run logs only the channel
registration — the local cross-city path is unchanged (`chk_suite.sh`'s stock control
and imported-player rows stay clean).

### Three cities at once — `tools/chk_mp_foreign.sh`

The stress the adapter exists for: a **different foreign city on each side** than
the level's own, with each player pointed at the imported model (`-mpcar <model>`)
rather than at one of the level's frontend slots. Measured
(`chk_mp_foreign.sh --seconds 35`, level CHICAGO, host HAVANA, client RIO,
`mp_agree_imports = 0` on both so each side keeps its own set):

```
host    import set: level CHICAGO, guest city HAVANA, 1 entry
host    cross-city: car data from HAVANA (131412 bytes of models, 14792 of car palettes)
host    cross-city: slot 5 geometry from HAVANA model 8
host    JERICHO-DIAG: player slot=5 (model=8, want=8, startinfo[0]=8) residents= 1 2 3 0 4 8 11 9

client  import set: level CHICAGO, guest city RIO, 1 entry
client  cross-city: car data from RIO (135688 bytes of models, 15704 of car palettes)
client  cross-city: slot 5 geometry from RIO model 9
client  JERICHO-DIAG: player slot=5 (model=9, want=9, startinfo[0]=9) residents= 1 2 3 0 4 9 11 8

[pair] verdict: host_joins=1/1 joiners_accepted=1/1 lost=0 dumps=0 -> PASS
```

So: three cities' data in play across the pair (Chicago the level, Havana on the
host, Rio on the client), **each player spawning in its own imported car** —
`InitPlayer` resolved `want=<model>` to `slot=5`, the slot carhacks imported into —
and the session live (mp's `adopt: player 1 snap …` counter climbing throughout).

The same script with `--host-both` asks the host for a second foreign city
(`import = 5:1:8, 6:3:9`). That used to be REFUSED loudly - the entry dropped and
only one car imported:

```
host  [carhacks] import: slot 6 wants RIO but this level already reads cars from HAVANA -
      the engine holds ONE source city per level, so the entry is dropped
host  [carhacks] import set: level CHICAGO, guest city HAVANA, 1 entry, version 2
```

With the gate gone both load. Measured 2026-10-03 on CHICAGO: a 5-entry set naming
HAVANA, VEGAS and RIO reported `import set: level CHICAGO, guest cities 3, 5
entries`, imported all 5, and each slot built its geometry from its own city.

### Every player's car, on every machine

Three seats (host + two staggered joiners: `mp_pair.bat --players 3 --stagger 12`),
the players in different cars. Seat **c** - the second joiner, which never talks to
seat b, and whose own `PICK` would only ever have reached the host - ends up
knowing all three cars:

```
seat c  [carhacks/net] cars (from the host): 0=level model 1, 1=level model 3, 2=level model 3
seat b  [carhacks/net] cars (from the host): 0=level model 1, 1=level model 3, 2=level model 3
[pair] verdict: host_joins=2/2 joiners_accepted=2/2 dumps=0 -> PASS
```

Over the divergent pair the client ends up with the truth about a car it could
never derive locally (its own slot 5 holds Rio's car, the host drives Havana's):

```
client  [carhacks/net] cars (from the host): 0=HAVANA model 8, 1=RIO model 9
```

### Drawing a peer's car — measured

`chk_mp_foreign.sh` with `CHK_FORCE_PLAYER_PALETTE=2` (so the owner reports a
palette that is NOT the one this machine can honour). Each side imports its own
city into slot 5, so each draws the other as its own imported vehicle — and says
so, then corrects the colours:

```
seat a  peer 1 drives RIO model 9, but this machine draws HAVANA model 8 in slot 5
        - using that car's own colours (theirs is not loaded here)
        [mp] palette: player 1 reports 2, drawn as 0 (corrected: not their car here)
seat b  peer 0 drives HAVANA model 8, but this machine draws RIO model 9 in slot 5
        [mp] palette: player 0 reports 2, drawn as 0 (corrected: not their car here)
[pair] verdict: host_joins=1/1 joiners_accepted=1/1 dumps=0 -> PASS
```

One line per change, not per packet — the state stream is continuous. The fold adds
the peer's car to the set like any other entry, from whatever city it belongs to
(`chkNetFoldPeerCars`), and `chk_suite.sh`'s single-import rows stay clean.

### Releasing a slot — measured (Windows)

`mp_tries.py --scenario T2/T3/T5/T6` on the Windows box, 2026-10-04, build
`0.9.0-42-g1d88177d`. The release routine produced exactly the verdicts it promises,
and the pool summary is the leak detector it was meant to be:

- **T2** — 7 switches against 6 spares: `released - nobody names it and no car is on
  it` on host and client for every switch, `pages 2 used / 28 free` unchanged
  throughout, and no `no spare resident slot`. PASS.
- **T3** — two joiners on the same car, one leaves: `kept - still named by player 2`.
- **T5** — `deferred - car 1 still on it` then `released`; on a faster run the host has
  already re-modelled the car when the PICK lands and the release goes straight
  through. Both outcomes are correct, which is why the defer is reported by the rig
  rather than required of the run.
- **T6** — the shared car's slot stays while the other import's slot goes, and
  `crosscheck.py`'s invariants still hold (0 fail, 5 warn).

Two failures in that run were the **rig**, not the module, and both are fixed:
the scenarios named their cars by model number while driving them with a roster SLOT
(slot 1 is model 2 — `mp_tries.py` now goes through `CAR_SLOT_TO_MODEL`), and a 3-seat
run on one desktop is unreliable (T6's third seat never launched at all). A stray
pause-menu `Respawn as this car` activation also changes cars behind the scenario's
back; that is an input/desktop effect, not the release path.

### Not verified

- **The hotload itself** (above): a peer's car from a city this machine does not
  hold is *corrected*, not loaded — right colours, wrong vehicle, and reported. The
  runtime load is the next unit, and the numbers it has to fit are recorded above.
- A session where the two machines' configs genuinely differ *and* the agreement is
  ON: mp's pair harness copies one `JERICHO/CONFIG` into both run dirs, so host
  authority is verified by construction and by the logs above, not by a
  divergent-config run. The three-city run deliberately turns the agreement off
  (`mp_agree_imports = 0`) for the same reason.

## The live-car request — `mplive.{c,h}`, and mp's pause menu

mp's Multiplayer pause page has a `Change car` picker (city, car, apply). The
picker is mp's, but two of the things it needs are carhacks', so mp ASKS for them
over two custom JERICHO events — the contract is
`Game/C/JERICHO/include/jer_carquery.h` (a core contract header), the one place the ids and argument structs are
written down, and `mplive.c` is the carhacks side:

| Event | mp asks | carhacks answers |
| --- | --- | --- |
| `JER_CARQ_CITIES` | which cities can this session offer? | every car-data city this install HAS (`chkCityCount()`: CHICAGO..RIO, Driver 1's seven, and any runtime bank registered in `JERICHO/CONFIG/cities.ini` whose files are on disk), or `count = 0` for "nobody knows" (the roster hack `unlock_extra_vehicles` is off, so this machine's picker has only the level's own city) |
| `JER_CARQ_LOAD` | make `(city, model)` available here | `ok = 1` once the slot is set and built |
| `JER_CARQ_CHOSEN` | (a notice, no answer) the local player is now driving `(city, model)` - or, `changed = 0`, the switch did not happen | updates carhacks' identity for this player, tells the session, and releases the old car's slot through the release routine |

`JER_CARQ_LOAD` is not new machinery. It is the sequence a mid-match peer pick
already goes through: `chkImportSlotForCar` (a car already in the set keeps its
slot — re-slotting it would move a car somebody may be driving), else
`chkImportCanonicalSlot` for OUR player id, then `chkImportSetSlot` +
`chkImportHotLoad` (which writes the slot's identity into the engine's arrays,
reads that city in, builds the slot's geometry in the engine's own pool, applies
its cosmetics and records its texture pages). It does NOT tell the session any
more: a car is advertised only once the player is really driving it.
`JER_CARQ_CHOSEN` (fired by `MpChangeCar` after the swap, and by `MpFollowLocalCar`
when the player gets back into a car on foot) does that: `ChkMpChosen` ->
`chkNetLocalSwitched` sets carhacks' local pick, advertises it
(`chkNetAdvertisePick`; on the host, `chkNetBroadcastCars` + `chkNetPublishSet`) so
every other machine loads it too, and then runs the release routine on the old car's
slot. A `changed = 0` notice (the load worked but the swap did not) releases the
newly loaded slot again if nobody names it. A failed load releases a slot it had
just taken.

`ok` is only 1 when `gCarCleanModelPtr[slot]` is non-NULL after that: mp is about
to point a car at this slot, and a slot with no built geometry is a crash, not a
cosmetic glitch.

Measured on the pair rig (`MP_TEST_PAUSECAR=40,1`, which runs the same call the
Apply row does — HAVANA model 2 on a RIO map): the host logs `rebuilt player 0's
car on slot 7 (model 2 from HAVANA)`, `told the session: HAVANA model 2`, and the
client logs `cars (from the host): 0=HAVANA model 2` with HAVANA's palettes
uploaded for its block. So the runtime import path above is now exercised by a
live pick, not only by the level-load walk.

Picking away from a car now frees its slot (#14), through the release routine
described in "Releasing a slot" above. `MP_TEST_PAUSECAR` takes a list of timed
switches (`30,3,1;45,1,2`), so the rig can switch until the spares would run out
(`mp_tries.py --scenario T2`).
