BIGRIG - three-car Driver 2 car-data bank
==========================================

Source: the Chicago big rig. Destination slots 10, 11 and 12:
  10  full truck
  11  truck cab only
  12  trailer only

Files:
  bank.json               the declaration (slot order, cars, pages)
  BIGRIG.LEV / .LCF       installed copies of build/ (loadable pair)
  build/                  the bake output: NAME.LEV/.LCF, NAME.json,
                          NAME.report.json, models/, pages/, portraits
  BIGRIG.portraits/       car-select portraits for slots 10, 11, 12
  cities.ini              fallback registration for older games

Install: carhacks 0.2.7+ (packbanks) registers every enabled mod's
banks/<dir>/bank.json on its own. Enable this mod under Mods, then play.
Older games: add the city_0 line from cities.ini under [cities] in
JERICHO/CONFIG/cities.ini.
