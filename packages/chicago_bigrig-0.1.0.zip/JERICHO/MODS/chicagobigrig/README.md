# Chicago Big Rig

The Chicago big rig from Driver 2 as a JERICHO BAKE car bank (`BIGRIG`), with
three cars:

| slot | car |
|---|---|
| 10 | full truck |
| 11 | truck cab only |
| 12 | trailer only |

Each has clean, damaged and low LODs; the damaged and low models are stand-ins
for now. The bank carries its own pages, wheel page, portraits and sounds.

## Install

From the in-game mod store (Chicago Big Rig): install, then **Mods → enable** it,
then play. `default-enabled` is false, so packbanks (carhacks 0.2.7+) registers
BIGRIG only after that enable writes `chicagobigrig = 1` in `modlist.ini`. The
big rig vehicles show up in the car menu under BIGRIG.

Older games, or a hand copy to `JERICHO/MODS/chicagobigrig/`: add the `city_0`
line from `banks/bigrig/cities.ini` under `[cities]` in
`JERICHO/CONFIG/cities.ini`. See `banks/bigrig/README.txt`.

## Layout

    mod.toml, README.md        this manifest and note
    banks/bigrig/bank.json     slot order, cars and page declarations
    banks/bigrig/BIGRIG.LEV    the loadable baked bank
    banks/bigrig/BIGRIG.LCF    its handling/colour pair
    banks/bigrig/build/        the bake output (models, pages, portraits, report)
    banks/bigrig/cities.ini    fallback registration for older games

The package is the player payload: the authoring OBJ/MTL, Blender and Paint.NET
sources stay out of the download. Rebake from the source tree with BAKE.
