## Install
From the in-game mod store (Chicago Big Rig): install, then **Mods → enable** it, then play.
`default-enabled` is false, so packbanks (carhacks 0.2.7+) registers BIGRIG only after that enable
writes `chicagobigrig = 1` in `modlist.ini`. The big rig vehicles show up in the car menu under BIGRIG.

Older games, or a hand copy to `JERICHO/MODS/bigrig/`: add the `city_1` line from
`banks/bigrig/cities.ini` under `[cities]` in `JERICHO/CONFIG/cities.ini`. See `banks/bigrig/README.txt`.
