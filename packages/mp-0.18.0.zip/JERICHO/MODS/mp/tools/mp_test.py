#!/usr/bin/env python3
"""mp_test.py -- headless protocol harness for the JERICHO Multiplayer module.

The game writes JERICHO.log relative to its CWD, so two live instances
cannot run from one folder. Instead this harness drives the real module
against a scriptable Python peer, exercising the actual wire protocol on
whichever side the game is playing:

  host   LISTEN -- accept the game's MP_HELLO and answer MP_WELCOME (so the
                  game acts as the CLIENT).  Verifies the client handshake,
                  HELLO encoding, WELCOME decoding and the player registry.

  client HOST -- connect to the game's listener, send an MP_HELLO and print
                  the reply (so the game acts as the HOST).  --mods sends an
                  empty/garbage manifest; --build forces a version mismatch.

  beacon PORT -- bind UDP PORT and print every MP_BEACON received (verifies
                  the host's discovery advertisement).

Wire format mirrors JERICHO/MODS/mp/mp_proto.h (little-endian, pack(1)).
"""
import argparse
import math
import socket
import struct
import sys
import threading
import time

PROTO = 21                    # mp_proto.h MP_PROTO_VERSION (21: a car's city byte past the stock rows is a bank NAME code 0x80..0xFE; 20: MP_ROSTER_ENTRY carries leftModel/leftModelCity, 32 bytes; 19: dynamic JMPPED entries on top of 18's ped model id) -- the game drops any frame whose envelope version differs
SDK = 3                       # JERICHO_SDK_VERSION
MP_VER = "0.17.0"             # JERICHO/MODS/mp/mod.toml version -- always advertised
NUL = bytes([0])

# Shared protocol constants, mirrored from mp_proto.h so the tools never hard-code
# them twice. servers/proto_check.py asserts these (and the struct sizes below) still
# match the C header, because a mirror that drifts fails silently on the wire.
MAX_PLAYERS = 16              # mp_proto.h MP_MAX_PLAYERS
NAME_MAX = 32                 # mp_proto.h MP_NAME_MAX (MP_BEACON.hostName / MP_HELLO.playerName)
MOD_ID_MAX = 24               # mp_proto.h MP_MOD_ID_MAX (MP_MOD_INFO.id)
MOD_VER_MAX = 16              # mp_proto.h MP_MOD_VER_MAX (MP_MOD_INFO.version)

# The engine's city ROW capacity (system.h: CITY_D2_COUNT 4 + CITY_D1_COUNT 7 +
# CITY_CUSTOM_MAX 16). A car pick/roster modelCity is a valid cross-city source
# for 0..CITY_COUNT-1 (0xFF = MP_CAR_CITY_SESSION, "the session's own city").
# NOTE: this mirrors system.h, not mp_proto.h, so proto_check.py does NOT verify
# it -- it is hand-kept beside the C header like the struct formats are.
CITY_COUNT = 27
# proto 21: a runtime bank's city byte is a code from its NAME (jer_carquery.h
# JER_CITY_WIRE_CODE_FIRST..LAST), never its row number on the sending machine.
CITY_WIRE_CODE_FIRST = 0x80
CITY_WIRE_CODE_LAST = 0xFE

# Session rules, packed into ONE byte (mp_proto.h MP_RULES_PACK). The beacon now
# carries this so a browser can NAME a server's mode without joining it.
MP_RULE_COPS = 0x1            # 1 = police cars spawn


GAMEMODE_NAMES = {0: "TAKE A RIDE"}      # MP_GAMEMODE_* (mp_proto.h)


def mode_name(gamemode):
    """The name a browser shows for a server's gamemode id. Session rules (cops
    on/off) never rename the mode. Keep in step with MpModeName (mp_session.c)."""
    return GAMEMODE_NAMES.get(gamemode, "-")


def city_name(city):
    """The engine's city names, in GameLevel order (LevelNames in the engine)."""
    names = ("CHICAGO", "HAVANA", "LAS VEGAS", "RIO")
    return names[city] if 0 <= city < len(names) else "UNKNOWN"

TAG = {
    "hello": b"JPHL", "welcome": b"JPWL", "reject": b"JPRJ",
    "start": b"JPST", "input": b"JPIN",
    "carstate": b"JPCS", "ping": b"JPPN", "pong": b"JPPO",
    "channel": b"JPCH", "leave": b"JPLV", "kick": b"JPKK", "chat": b"JPCX",
    "roster": b"JPRS", "car": b"JPCC",
    "ped": b"JPPD", "traffic": b"JPTF", "hit": b"JPHI", "color": b"JPCL",
    "stats": b"JPSX",
}
# NOTE: no "session" entry. 'JPSS' was retired from mp_proto.h -- it was reserved for
# a standalone session/lobby broadcast that nothing ever sent or handled. Keep this
# table to the tags the code actually has; a retired one is dropped here too.
# MP_PEDSTATE (count + 3 reserved) and its 24-byte MP_PEDSTATE_ENTRY rows
# (playerId, flags, pedModel, spare, x, y, z, heading, speed): an on-foot player's
# pose, carrying the owner's current character.
PEDSTATE = struct.Struct("<B3x")
PEDSTATE_ENTRY = struct.Struct("<BBBBiiiii")
# MP_PED_MODEL_*: the wire values are stable (mp_proto.h).
PED_MODEL_TANNER = 0
PED_MODEL_JERICHO = 1
PED_MODEL_COP = 2
PED_MODEL_CIVILIAN = 3
# MP_HIT: targetId, flags (MP_HIT_F_TRAFFIC = targetId is a car_data slot), 2 reserved,
# int32 impulse[3], uint32 targetFrame, int32 tgtPos[3] (32 bytes since proto 14).
# MP_COLOR: count + 3 reserved, then 8-byte rows
# (playerId, on, r, g, b, pedModel, 2 spare). (MP_CHANNEL is CHANNEL, below.)
HIT = struct.Struct("<BB2xiiiI3i")
HIT_F_TRAFFIC = 0x01
# MP_STATS (count + 3 reserved) + 12-byte MP_STATS_ENTRY rows: playerId, lossPct
# (0xFF = unknown), pingMs, rxBps, txBps -- each player's link to the hub.
STATS = struct.Struct("<B3x")
STATS_ENTRY = struct.Struct("<BBHII")
STATS_LOSS_UNKNOWN = 0xFF
CAR_PICK = struct.Struct("<BB2x")    # MP_CAR: model (0xFF none), city (0xFF = session)
COLOR = struct.Struct("<B3x")
COLOR_ENTRY = struct.Struct("<BBBBBB2x")  # playerId, on, r, g, b, pedModel, 2 spare
TRAFFIC_SLOT_FIRST = 20          # dr2limits.h JER_SLOT_TRAFFIC_FIRST (MAX_CARS 32 - 12)
TRAFFIC_SLOT_COUNT = 12
# MP_TRAFFIC (frame, count, reserved[3]) and its 56-byte MP_TRAFFIC_ENTRY rows (carSlot, flags,
# model, modelCity, palette, reserved1, damage[6], totalDamage, orient[4], x, y, z, heading, vel[3])
TRAFFIC = struct.Struct("<IB3x")
TRAFFIC_ENTRY = struct.Struct("<6B6hH4h4i3i")
MAX_CARS = 32
UDP_MAGIC = 0x31504D4A
DISCOVERY_PORT = 1318          # mp_proto.h MP_DISCOVERY_PORT -- FIXED and shared. A
                               # beacon goes HERE; the session port travels INSIDE
                               # the beacon (MP_BEACON.port), which is why a
                               # listener binds this port and not the session's

ENV = struct.Struct("<I4sBBH")
HELLO = struct.Struct("<HHHH32s4B")      # 44 bytes
MODI = struct.Struct("<24s16sBB")        # 42 bytes
WELCOME = struct.Struct("<12BIBB")      # 18 bytes: 12xu8, u32 seed, u8 hostCar, u8 rules (mp_proto.h static_assert -- v11 ADDED `rules`; a 17-byte <12BIB is refused by MpHandleWelcome's length gate)
REJECT = struct.Struct("<4B64s")         # 68 bytes
BEACON = struct.Struct("<IHH32s6BHH")    # 50 bytes; the last u16 is `rules` (mp_proto.h renamed MP_BEACON's `spare` to it -- same offset, same size, so the wire is unchanged)
CHANNEL = struct.Struct("<16sHIBB2B")    # 26 bytes
# Byte offset of MP_CHANNEL.fromPlayer. A relay must stamp this with the sender's real
# player id: once the frame leaves the sender, the header is the only record of who it
# was, and a client has one link (to the host/server) that says nothing about it.
CHANNEL_FROM_OFFSET = struct.calcsize("<16sHIB")  # 23 (name + len + frame + reliable)
CHAT = struct.Struct("<B3B96s")          # 100 bytes: playerId, reserved[3], text[96]
KICK_FLAG_REJOIN = 0x01                  # KICK reserved[0]: the server is changing city, rejoin shortly
KICK_TEXT_LEN = 64                       # optional KICK tail: NUL-terminated text shown to the player
KICK = struct.Struct("<B3B")             # 4 bytes: playerId, reserved[3] -- the host
                                         # removing a player (the client acts on it)
SESSION = struct.Struct("<4BIBBH")       # 12 bytes (gamemode,city,tod,weather,seed,numPlayers,state,spare)
INPUT = struct.Struct("<B3B")            # count, reserved[3] = 4 (the frame byte was dropped)
PLAYER_INPUT = struct.Struct("<BHB")     # playerId, pad, spare = 4
CARSTATE = struct.Struct("<IB3B")        # frame, count, reserved[3] = 8
CARSTATE_ENTRY = struct.Struct("<BBBBB4h3ii3i3iBBBB")  # pid, flags, palette, model, modelCity, orient[4], x,y,z, heading, angVel[3], vel[3], leftModel, leftModelCity, hubcaps, crushScale = 57 (model 0xFF = on foot; modelCity 0xFF = the session city; hubcaps low nibble = lost wheel hubcaps; crushScale = owner's body-crush multiplier in half steps, 2 = 1.0x, 20 = 10.0x)
CARSTATE_LEFT_CAR = 4          # mp_proto.h MP_CARSTATE_LEFT_CAR: the NO_CAR row also names the parked car

# The roster (JPRS). The HOST broadcasts it before a launch and refreshes it every
# couple of seconds; a client learns its PEERS only from it, and adopts their cars
# when MP_ROSTER_FLAG_CAR_READY is set. Only the first `count` entries are on the
# wire (the C side sends sizeof(MP_ROSTER) less the unused rows), which is why the
# frame is a header + count*ROSTER_ENTRY rather than a fixed MP_ROSTER.
ROSTER_NAME_MAX = 20          # mp_proto.h MP_ROSTER_NAME_MAX
ROSTER_FLAG_HOST = 1          # mp_proto.h MP_ROSTER_FLAG_HOST
ROSTER_FLAG_CAR_READY = 2     # mp_proto.h MP_ROSTER_FLAG_CAR_READY
ROSTER = struct.Struct("<4B")          # count, reserved[3] = 4
ROSTER_ENTRY = struct.Struct("<6B2H2B20s")  # id, carId, model, modelCity, flags, pedModel, ping, palette, leftModel, leftModelCity, name[20] = 32 (model 0xFF = on foot)

REJECT_NAMES = {0: "NONE", 1: "FULL", 2: "VERSION", 3: "MODS", 4: "INPROGRESS", 5: "CUSTOM"}
REJECT_IDS = {v.lower(): k for k, v in REJECT_NAMES.items() if k != 0}


def cstr(raw):
    return raw.split(NUL)[0].decode(errors="replace")


def send_frame(sock, tag, payload=b""):
    sock.sendall(ENV.pack(8 + len(payload), tag, PROTO, 0, 0) + payload)


def _recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def recv_frame(sock):
    head = _recv_exact(sock, ENV.size)
    if head is None:
        return None, None
    length, tag, ver, flags, _ = ENV.unpack(head)
    payload = _recv_exact(sock, length - 8) if length > 8 else b""
    if payload is None:
        return None, None
    return tag, payload


HELLO_ID_TAG = b"JPID"                   # mp_proto.h MP_HELLO_ID_TAG
PLAYER_ID_LEN = 16                      # mp_proto.h MP_PLAYER_ID_LEN
HELLO_VER_TAG = b"JPVR"                  # mp_proto.h MP_HELLO_VER_TAG
HELLO_VER_MAX = 16                      # mp_proto.h MP_HELLO_VER_MAX (JPID+JPVR < one 42-byte row)


def build_hello(name, mods=(), build=0, player_id=None, version=None):
    """MP_HELLO + its manifest, then (optionally) the JPID player-id block and
    the JPVR build block (the game sends both; JPVR only after JPID)."""
    body = HELLO.pack(PROTO, SDK, build, 0, name.encode()[:31], len(mods), 0, 0, 0)
    for mid, ver in mods:
        body += MODI.pack(mid.encode()[:23], ver.encode()[:15], 1, 0)
    if player_id is not None:
        if len(player_id) != PLAYER_ID_LEN:
            raise ValueError("player id must be %d bytes" % PLAYER_ID_LEN)
        body += HELLO_ID_TAG + bytes(player_id)
    if version is not None:
        v = version.encode("ascii", "replace")[:HELLO_VER_MAX]
        body += HELLO_VER_TAG + bytes([len(v)]) + v
    return body


def parse_hello_version(payload):
    """The JPVR build string after the manifest (and the JPID block, when there
    is one), or None for a client too old to send it. Display only."""
    if len(payload) < HELLO.size:
        return None
    modc = HELLO.unpack_from(payload, 0)[5]
    at = HELLO.size + modc * MODI.size
    if payload[at:at + 4] == HELLO_ID_TAG and len(payload) >= at + 4 + PLAYER_ID_LEN:
        at += 4 + PLAYER_ID_LEN
    if len(payload) < at + 5 or payload[at:at + 4] != HELLO_VER_TAG:
        return None
    n = min(payload[at + 4], HELLO_VER_MAX)
    raw = payload[at + 5:at + 5 + n]
    return "".join(chr(c) if 32 <= c <= 126 else "?" for c in raw)


def mods_digest(mods):
    """The join toast's "mods 3fa2c1": CRC-32 of "id:version;" for every ENABLED
    manifest row (id, version, enabled), sorted by id, masked to 24 bits. The
    same as the game's MpModsDigest (mp_config.c) -- keep the two in step."""
    import zlib
    rows = sorted((r for r in mods if r[2]), key=lambda r: r[0].encode("latin1", "replace"))
    text = "".join("%s:%s;" % (r[0], r[1]) for r in rows)
    return zlib.crc32(text.encode("latin1", "replace")) & 0xFFFFFF


def parse_player_id(payload):
    """The JPID block after a HELLO's modCount manifest rows, as a dashed UUID
    string, or None when the client sent none (an older build)."""
    if len(payload) < HELLO.size:
        return None
    modc = HELLO.unpack_from(payload, 0)[5]
    at = HELLO.size + modc * MODI.size
    if len(payload) < at + 4 + PLAYER_ID_LEN or payload[at:at + 4] != HELLO_ID_TAG:
        return None
    return format_player_id(payload[at + 4:at + 4 + PLAYER_ID_LEN])


def format_player_id(raw):
    """16 bytes -> the dashed UUID form (8-4-4-4-12, lowercase) every tool shows."""
    h = bytes(raw).hex()
    return "%s-%s-%s-%s-%s" % (h[:8], h[8:12], h[12:16], h[16:20], h[20:])


def normalize_player_id(text):
    """A player id typed by a person -- dashed or plain hex, any case, braces ok --
    as the canonical dashed lowercase form, or None if it is not 16 bytes of hex."""
    h = str(text or "").strip().strip("{}").replace("-", "").lower()
    if len(h) != PLAYER_ID_LEN * 2 or any(c not in "0123456789abcdef" for c in h):
        return None
    return format_player_id(bytes.fromhex(h))


# ---------------------------------------------------------------- modes
def mode_host(args):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", args.port))
    srv.listen(4)
    print(f"[mock-host] listening on {args.port}; waiting for the game's HELLO")

    if args.beacon:
        beacon_start(args.beacon_port, args.beacon_name, args.port,
                     args.beacon_in_progress, args.beacon_interval)

    srv.settimeout(args.timeout)
    try:
        conn, addr = srv.accept()
    except socket.timeout:
        print("[mock-host] FAIL: no connection")
        return 1
    print(f"[mock-host] connection from {addr}")
    conn.settimeout(args.timeout)
    tag, payload = recv_frame(conn)
    if tag != TAG["hello"]:
        print(f"[mock-host] FAIL: expected HELLO, got {tag!r}")
        return 1
    proto, sdk, build, _spare, name, modc, _r0, _r1, _r2 = HELLO.unpack_from(payload, 0)
    mods = [MODI.unpack_from(payload, HELLO.size + i * MODI.size) for i in range(modc)]
    modnames = [cstr(m[0]) for m in mods]
    print(f"[mock-host] HELLO: proto={proto} sdk={sdk} build={build:#06x} name={cstr(name)!r}")
    print(f"[mock-host]         mods({modc}): {', '.join(modnames) or '(none)'}")
    if proto != PROTO or sdk != SDK:
        print("[mock-host] FAIL: protocol/SDK mismatch from the game")
        return 1

    # Stay silent for a while, so the game sits in the handshake and keeps its
    # discovery browser open -- that is the window same-machine discovery needs.
    if args.hold_hello > 0:
        print(f"[mock-host] holding the handshake {args.hold_hello}s (staying silent)")
        time.sleep(args.hold_hello)

    # Mimic the real host's reject path: send MP_REJECT, then close. --reject-hold
    # keeps the socket open first (isolates "the REJECT was lost" from "the close
    # raced the REJECT"); --reject-graceful half-closes and drains instead of
    # slamming the socket shut (isolates the RST race).
    if args.reject and args.reject != "none":
        rid = REJECT_IDS[args.reject]
        text = args.reject_text or f"mock reject: {args.reject}"
        send_frame(conn, TAG["reject"], REJECT.pack(rid, 0, 0, 0, text.encode()[:63]))
        print(f"[mock-host] sent REJECT {args.reject.upper()} ({rid}) -- {text!r}")
        if args.reject_hold > 0:
            time.sleep(args.reject_hold)
        if args.reject_graceful:
            try:
                conn.shutdown(socket.SHUT_WR)
                conn.settimeout(2.0)
                while True:
                    if not conn.recv(4096):
                        break
            except OSError:
                pass
        conn.close()
        return 0
    welcome = WELCOME.pack(1, 8, 0, 1, 1 if args.start else 0, 0, 0, 0, 0, args.city, 1, 0, 1234, 0xFF, 0)
    send_frame(conn, TAG["welcome"], welcome)
    print("[mock-host] sent WELCOME (playerId=1) -- PASS")

    if args.start:
        sess = SESSION.pack(0, args.city, 1, 0, 1234, 2, 1, 0)
        send_frame(conn, TAG["start"], sess)
        print(f"[mock-host] sent START (city={args.city})")

    # Service the connection. A real host does NOT hang up the moment it has said
    # hello: it answers keepalives and stays up. Closing 0.5 s after WELCOME is
    # exactly why a joining client logged "Lost the server" seconds into an
    # otherwise clean handshake. So: always reply to PING with PONG, service
    # input/car-state with --lockstep, and stay up until the client goes away
    # (or --hold seconds pass).
    conn.settimeout(1.0)
    seen = 0
    carstate = 0
    last = None
    deadline = time.time() + args.hold if args.hold > 0 else None
    while deadline is None or time.time() < deadline:
        try:
            tag, payload = recv_frame(conn)
        except socket.timeout:
            continue
        except OSError:
            break
        if tag is None:
            print("[mock-host] client closed the connection")
            break
        if tag == TAG["ping"]:
            send_frame(conn, TAG["pong"], payload if payload else b"\0\0\0\0")
        elif tag == TAG["input"] and args.lockstep:
            frame, count, _a, _b, _c = INPUT.unpack_from(payload, 0)
            rows = [PLAYER_INPUT.unpack_from(payload, INPUT.size + i * PLAYER_INPUT.size) for i in range(count)]
            peer_pad = rows[0][1] if rows else 0
            out = INPUT.pack(frame, 2, 0, 0, 0)
            out += PLAYER_INPUT.pack(0, args.peer_pad, 0)   # the fake host player's own pad
            out += PLAYER_INPUT.pack(1, peer_pad, 0)       # echo the client's own pad (player 1)
            send_frame(conn, TAG["input"], out)
            seen += 1
        elif tag == TAG["carstate"] and args.lockstep and not args.no_carstate:
            frame, count, _a, _b, _c = CARSTATE.unpack_from(payload, 0)
            if count >= 1:
                pid, _fl, _pal, _md, _mcy, _o0, _o1, _o2, _o3, x, y, z, hd, _a0, _a1, _a2, _v0, _v1, _v2, _lm, _lmc, _hub, _crush = CARSTATE_ENTRY.unpack_from(payload, CARSTATE.size)
                last = (x, y, z, hd)
                if not hasattr(args, "_fixed") or args._fixed is None:
                    args._fixed = (x + args.peer_dist, y, z)
                    print(f"[mock-host] pinning 'host' car at {args._fixed} "
                          f"(client spawn {x},{y},{z}, {args.peer_dist} away)")
                    # NO meeting-point message any more: the line-up (and its
                    # 'JPSW' tag) was retired -- both machines place their cars at
                    # the engine's own spawn and a client gathers itself beside the host.
                fx, fy, fz = args._fixed
                # static "host" car: it must NOT follow the client's car
                cs = CARSTATE.pack(frame, 1, 0, 0, 0)
                cs += CARSTATE_ENTRY.pack(0, 1, 0, 0, 0xFF, 0, 0, 0, 0, fx, fy, fz, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2)
                send_frame(conn, TAG["carstate"], cs)
                carstate += 1
    print(f"[mock-host] served {seen} input / {carstate} car-state frame(s); last client car {last}")
    conn.close()
    return 0


def beacon_start(port, name, session_port, in_progress, interval):
    """Broadcast MP_BEACON like a real host, in a daemon thread.

    Deliberately NOT bound to the port: sending needs no bind, so a mock host
    can advertise while a real game listens on the same machine.
    """
    def run():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        body = BEACON.pack(UDP_MAGIC, PROTO, session_port,
                           name.encode()[:31], 1, 8, 0, 0, 0, in_progress, 0x1234,
                           0)   # rules: this mock host carries none
        n = 0
        while True:
            try:
                s.sendto(body, ("255.255.255.255", port))
                n += 1
                if n == 1:
                    print(f"[mock-host] beaconing '{name}' on UDP/{port} (session {session_port})")
            except OSError as e:
                print(f"[mock-host] beacon failed: {e}")
            time.sleep(interval)

    t = threading.Thread(target=run, daemon=True)
    t.start()
    return t


def mode_client(args):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(args.timeout)
    s.connect((args.host, args.port))
    print(f"[mock-client] connected to {args.host}:{args.port}")

    # The mp mod is ALWAYS advertised: it *is* the multiplayer system and the
    # game side always has it enabled (JERICHO lists every enabled module in
    # its HELLO). --mods adds the extra entries a server may require -- the
    # dedicated example asks for the core suite, so a normal e2e join declares it.
    mods = [("mp", MP_VER)]
    for extra in args.mods:
        if extra not in ("empty", "mp"):
            mods.append((extra, "1.0.0"))
    hello = build_hello(args.name, mods, args.build)

    if args.proto is not None:
        # the hello is <proto, sdk, ...>: overwrite the two version fields
        hello = HELLO.pack(args.proto, SDK, args.build, 0,
                           args.name.encode()[:NAME_MAX], len(mods), 0, 0, 0) + hello[HELLO.size:]

    send_frame(s, TAG["hello"], hello)
    print(f"[mock-client] sent HELLO (name={args.name}, mods={[m[0] for m in mods]}, build={args.build:#06x})")

    # The host sends the ROSTER before the WELCOME (order is load-bearing: a live
    # joiner picks the players/cars from it), and it pings on a keepalive timer --
    # skip both while waiting for the actual reply.
    while True:
        tag, payload = recv_frame(s)
        if tag is None or tag not in (TAG["ping"], TAG["pong"], TAG["roster"]):
            break

    if tag == TAG["reject"]:
        reason, _r0, _r1, _r2, text = REJECT.unpack_from(payload, 0)
        print(f"[mock-client] REJECT: reason={REJECT_NAMES.get(reason, reason)} "
              f"text={cstr(text)!r}")
        print("[mock-client] the refusal reached us, which is the point")
        s.close()
        return 0

    if tag == TAG["welcome"]:
        (pid, maxp, enforce, matched, running, subgame, _r1, _r2, gm, city, tod, wx,
         seed, hostcar, rules) = WELCOME.unpack_from(payload, 0)
        print(f"[mock-client] WELCOME: playerId={pid} max={maxp} enforced={enforce} "
              f"matched={matched} running={running} subgame={subgame} gamemode={gm} city={city} "
              f"tod={tod} weather={wx} seed={seed} hostCar={hostcar} rules={rules:#x}")
        if args.watch > 0:
            seen = 0
            deadline = time.time() + args.watch
            s.settimeout(0.5)

            while time.time() < deadline:
                try:
                    t, pl = recv_frame(s)
                except socket.timeout:
                    continue

                if t is None:
                    break

                if t == TAG["chat"]:
                    who, _a, _b, _c, text = CHAT.unpack_from(pl, 0)
                    print(f"[mock-client] CHAT from player {who}: {cstr(text)!r}")
                    seen += 1

            print(f"[mock-client] watched {args.watch:.0f}s, {seen} chat line(s) relayed")

        if args.channel:
            body = b"hello-from-python"
            hdr = CHANNEL.pack(args.channel.encode()[:15], len(body), 0, 0, 1, 0, 0)
            send_frame(s, TAG["channel"], hdr + body)
            print(f"[mock-client] sent CHANNEL '{args.channel}' ({len(body)} bytes)")
            time.sleep(0.5)
        if args.drive:
            # wait for the host's START, then stream our (moving) car state
            deadline = time.time() + 15
            started = False
            while time.time() < deadline and not started:
                t, pl = recv_frame(s)
                if t is None:
                    break
                if t == TAG["start"]:
                    started = True
            if started:
                # wait for the host's own car-state so we spawn right next to it
                # (the host only starts broadcasting once ITS level has loaded,
                # which can take ~15 s, hence the generous deadline)
                hx, hz, hy = None, None, 30
                t_end = time.time() + 30
                while time.time() < t_end and hx is None:
                    try:
                        s.settimeout(0.5)
                        t, pl = recv_frame(s)
                    except socket.timeout:
                        continue        # not started broadcasting yet - keep waiting
                    except OSError:
                        break
                    if t is None:
                        break
                    if t == TAG["carstate"]:
                        _fr, _cnt, _a, _b, _c = CARSTATE.unpack_from(pl, 0)
                        for k in range(_cnt):
                            pk, _fl, _pal, _md, _mcy, _sl, _o0, _o1, _o2, _o3, xk, yk, zk, hk, _a0, _a1, _a2, _v0, _v1, _v2, _lm, _lmc, _hub, _crush = CARSTATE_ENTRY.unpack_from(
                                pl, CARSTATE.size + k * CARSTATE_ENTRY.size)
                            if pk == 0:
                                hx, hz, hy = xk, zk, yk
                                break
                if hx is None:
                    hx, hz = -258443, -236292
                # tight grid right on the vanilla spawn (where the host's car
                # starts) so every car is visible together
                x = hx + (pid % 4) * 220 - 330
                lane = hz + (pid // 4) * 220 - 220
                print(f"[mock-client] spawning at {x},{lane} (vanilla spawn {hx},{hz})")
                drift = (pid - 4) * 0.45      # every client drives off in its own direction
                dxs = int(round(math.cos(drift) * 25))
                dzs = int(round(math.sin(drift) * 25))
                for f in range(900):
                    x += dxs
                    cs = CARSTATE.pack(f, 1, 0, 0, 0)
                    cs += CARSTATE_ENTRY.pack(pid, 1, 0, 0, 0xFF, 0xFF, 0, 0, 0, 0, x, hy, lane, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2)   # pid = us, at the host's ground height
                    send_frame(s, TAG["carstate"], cs)
                    lane += dzs
                    try:
                        s.settimeout(0.03)
                        while True:
                            recv_frame(s)
                    except (socket.timeout, OSError):
                        pass
                    time.sleep(1.0 / 30)
                    if f % 120 == 0:
                        print(f"[mock-client] driving: f={f} x={x}")
                print(f"[mock-client] streamed 900 car-state frames, final x={x}")
            else:
                print("[mock-client] no START received (host never started)")

        if args.chat:
            payload = CHAT.pack(1, 0, 0, 0, args.chat.encode()[:95])
            send_frame(s, TAG["chat"], payload)
            print(f"[mock-client] sent CHAT {args.chat!r}")
            time.sleep(0.6)

        print("[mock-client] PASS" if pid == 1 else "[mock-client] FAIL: unexpected playerId")
        s.close()
        return 0 if pid == 1 else 1
    if tag == TAG["reject"]:
        reason, _a, _b, _c, text = REJECT.unpack_from(payload, 0)
        print(f"[mock-client] REJECT: {REJECT_NAMES.get(reason, reason)} -- {cstr(text)!r}")
        print("[mock-client] PASS")
        s.close()
        return 0
    print(f"[mock-client] FAIL: unexpected reply {tag!r}")
    return 1


def mode_beacon(args):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    s.bind(("0.0.0.0", args.port))
    s.settimeout(args.timeout)
    print(f"[beacon] listening on UDP/{args.port} for host beacons")
    seen = 0
    t0 = time.time()
    while time.time() - t0 < args.duration:
        try:
            data, addr = s.recvfrom(2048)
        except socket.timeout:
            continue
        if len(data) < BEACON.size:
            continue
        magic, proto, port, host, players, maxp, gm, enforce, city, inprog, mhash, rules = BEACON.unpack_from(data, 0)
        if magic != UDP_MAGIC:
            continue
        print(f"[beacon] from {addr[0]}: proto={proto} port={port} "
              f"host={cstr(host)!r} players={players}/{maxp} "
              f"mode={gm} ({mode_name(gm)}) city={city} ({city_name(city)}) "
              f"enforced={enforce} inProgress={inprog} modHash={mhash:#06x} rules={rules:#04x}")
        seen += 1
    print(f"[beacon] {'PASS' if seen else 'FAIL'}: {seen} beacon(s)")
    return 0 if seen else 1


def main():
    ap = argparse.ArgumentParser(description="JERICHO mp protocol harness")
    sub = ap.add_subparsers(dest="mode", required=True)

    h = sub.add_parser("host", help="mock host: accept the game's HELLO")
    h.add_argument("--port", type=int, default=1318)
    h.add_argument("--timeout", type=float, default=15.0)
    h.add_argument("--city", type=int, default=1)
    h.add_argument("--start", action="store_true", help="after WELCOME, send MP_START to launch a level")
    h.add_argument("--lockstep", action="store_true", help="after START, service the client's MP_INPUT frames")
    h.add_argument("--drive", action="store_true", help="after START, stream a moving MP_CARSTATE for player 1")
    h.add_argument("--reject", default="none", choices=["none"] + list(REJECT_IDS),
                   help="send MP_REJECT then close, exactly like the real host does")
    h.add_argument("--reject-text", default="", help="text to carry in the REJECT")
    h.add_argument("--reject-hold", type=float, default=0.0,
                   help="seconds to keep the socket open after the REJECT (0 = close at once, like the real host)")
    h.add_argument("--reject-graceful", action="store_true",
                   help="half-close and drain after the REJECT instead of closing the socket")
    h.add_argument("--peer-dist", type=int, default=260,
                   help="how far the fake host car sits from the client's (default just in view)")
    h.add_argument("--no-carstate", action="store_true",
                   help="ignore the client's car-state, so only replicated input moves the cars")
    h.add_argument("--peer-pad", type=lambda v: int(v, 0), default=0,
                   help="pad the fake host player holds, in engine mapped bits (e.g. 0x40 = accelerate)")
    h.add_argument("--hold-hello", type=float, default=0.0,
                   help="seconds to stay silent after HELLO, stretching the client's handshake")
    h.add_argument("--beacon", action="store_true", help="broadcast discovery beacons while hosting")
    h.add_argument("--beacon-port", type=int, default=1318, help="discovery port to beacon on")
    h.add_argument("--beacon-name", default="MockBob's game", help="advertised host name")
    h.add_argument("--beacon-in-progress", type=int, default=0, help="1 = advertise as a live match")
    h.add_argument("--beacon-interval", type=float, default=1.0)
    h.add_argument("--hold", type=float, default=0.0,
                   help="seconds to keep the connection up after the handshake "
                        "(0 = until the client disconnects). A real host does not "
                        "close after saying hello; closing early made a client see "
                        "'Lost the server' right after a clean join.")
    h.set_defaults(func=mode_host)

    c = sub.add_parser("client", help="mock client: connect to the game's host")
    c.add_argument("host")
    c.add_argument("--name", default="PyTester", help="player name announced in HELLO")
    c.add_argument("--drive", action="store_true", help="after START, stream a moving MP_CARSTATE for player 1")
    c.add_argument("--chat", default="", help="after WELCOME, send one MP_CHAT line")
    c.add_argument("--port", type=int, default=1318)
    c.add_argument("--timeout", type=float, default=10.0)
    c.add_argument("--mods", action="append", default=[],
                   help="extra mod id to declare; 'mp' is ALWAYS included. Repeat for more "
                        "than one (the dedi's core suite, for example).")
    c.add_argument("--build", type=lambda v: int(v, 0), default=0x74cc,
                   help="game-build hash to send (default = current build; pass 0 to force a mismatch)")
    c.add_argument("--channel", default=None, help="after WELCOME, send an MP_CHANNEL payload on this channel name")
    c.add_argument("--watch", type=float, default=0.0,
                   help="after WELCOME, listen this many seconds and print CHAT frames, so a "
                        "relayed line can be seen without a game client")
    c.add_argument("--proto", type=int, default=None,
                   help="protocol version to declare (default: this mirror's) -- for testing a refusal")
    c.set_defaults(func=mode_client)

    b = sub.add_parser("beacon", help="UDP listener for host beacons")
    b.add_argument("--port", type=int, default=1318)
    b.add_argument("--timeout", type=float, default=2.0)
    b.add_argument("--duration", type=float, default=6.0)
    b.set_defaults(func=mode_beacon)

    args = ap.parse_args()
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
