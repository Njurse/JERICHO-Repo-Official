"""dedi.core -- the dedicated server itself: config, session loop, beacon, master
registration and the operator console. dediserver.py is the entry point.
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import struct
import sys
import threading
from urllib.parse import urlsplit
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # .../servers/dediserver
sys.path.insert(0, os.path.dirname(HERE))                            # .../servers (serverkit)

from serverkit import (LEVELS, Console, Log, apply_overrides, upgrade_config,   # noqa: E402
                       duration, install_signals, load_config)

TOOLS = os.path.dirname(os.path.dirname(HERE))      # .../mp/tools
SERVERS = os.path.dirname(HERE)                      # .../mp/tools/servers
sys.path.insert(0, TOOLS)
sys.path.insert(0, SERVERS)
import mp_test as m            # noqa: E402  the single Python source of truth
from dedi import relay   # noqa: E402  hit / colour / channel routing
from dedi.plugins import CONSOLE, Player, PluginManager, tick_loop   # noqa: E402
import proto_check            # noqa: E402  the wire-mirror guard


# ------------------------------------------------------------------------ config
DEFAULTS = {
    "port": 1318,
    "name": "Dedicated",
    "city": 0,                 # GameLevel the clients should load (0..3)
    "arena": 0,                # multiplayer arena index (the game's -mp 0 / -mp 1)
    "map_mode": "mp",        # "city" for the full single-player city, "mp" for multiplayer
    "gamemode": 0,
    "max_players": 16,         # a client takes a slot 1..max_players-1 (0 is the server);
                               # 16 is the protocol's cap (MP_MAX_PLAYERS)
    "motd": "",                # said to each joiner as a SERVER chat line ("" = nothing).
                               # One line: the wire field holds 95 characters.
    "motd_color": "#7FE8FF",   # that line's colour, "#RRGGBB". It rides in the chat
                               # frame's reserved bytes, so an older client just
                               # prints the default colour instead of failing.
    "beacon": True,            # advertise on UDP so the LAN browser lists us
    "beacon_ms": 1000,
    "idle_drop_s": 30.0,       # real silence before a client is dropped (0 = never)
    "live": True,              # advertise as a live match (the level is always up)
    # Session rules, readable (packed for the wire with MP_RULES_PACK's layout,
    # mp_proto.h). Defaults match an in-game host (mp_config.c): cops on, difficulty 1.
    "cops": True,              # police cars spawn at all
    "cop_difficulty": 1,       # 0..2 (MP_COP_DIFF_MAX)
    "cop_immunity": False,     # cops exist but never come after anyone
    "invulnerable": False,     # cars take no damage
    # Plugins (dedi/plugins.py; README "Plugins"). null = every plugin found, minus
    # plugins_disabled and any marked ENABLED_BY_DEFAULT = False; a list = exactly
    # those, in order. plugins_dir is relative to this server's folder.
    # The session's time of day and weather, by name (the engine's own lists:
    # FEmain.c TimeOfDayNames / WeatherNames). Read by a client as it loads.
    "time_of_day": "day",      # dawn | day | dusk | night
    "weather": "clear",        # clear | rain | wet
    "announce_joins": True,    # announce plugin: "X joined/left" as server chat
    "plugins": None,
    "plugins_disabled": [],
    "plugins_dir": "plugins",
    # admin plugin: player ids (from !whoami) that are admins on join, and an
    # optional shared password for !login ("" = no password logins).
    "admins": [],
    "admin_password": "",
    "log_level": "info",
    "log_file": "",
    # master discovery (optional). master = "" disables registration.
    "master": "http://jerichomp.animetiddi.es:8100",   # "" disables registration
    "master_name": "",
    "advertise_host": "",     # public address players reach us on ("" = the address we register from); set this behind NAT
    "advertise_port": 0,      # public port players dial (0 = our session port); set this when the router REMAPS it
    "mod_check": 0,            # 0 = admit anyone, 1 = ids must match, 2 = ids AND versions
    "core_mods": [],           # ids every client MUST have enabled (the core suite)
    "mods": [],                # when non-empty, the exact enabled-id set (no extras)
    "mod_versions": {},        # id -> version, consulted only by mod_check 2
    "master_interval_s": 20.0, # heartbeat cadence; keep well under the master's ttl
    "master_timeout_s": 5.0,
}

# How often the roster is re-broadcast. mp_session.c sends it every 120 frames,
# which is ~2s at 60 fps -- the same cadence a real host uses, so a client sees
# peers appear and leave on the timing it was written against.
ROSTER_REFRESH_S = 2.0

# Map shape published in MP_WELCOME.mpLevel and bit 0 of MP_SESSION.spare:
# 0 = full city (single-player map), 1 = multiplayer map. Arena selects MP map 0/1.
MAP_MODE_CITY = "city"
MAP_MODE_MP = "mp"

CONFIG_NAME = "dediserver.json"
EXAMPLE_NAME = "dediserver.example.json"   # tracked; dediserver.json is the operator's, untracked


def ensure_config(path, example):
    """Create `path` from `example` when it does not exist yet; NEVER touches an
    existing file (O_EXCL: a file that appears meanwhile wins too). Returns a line
    to log, or None when nothing was done."""
    if os.path.exists(path) or not os.path.exists(example):
        return None
    with open(example, "rb") as f:
        data = f.read()
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    except FileExistsError:
        return None
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    return "created %s from %s -- edit it to configure this server" % (path, os.path.basename(example))


def parse_manifest(payload):
    """The MP_MOD_INFO rows that ride after an MP_HELLO, as [(id, version, enabled)].

    The manifest travels INSIDE the hello frame rather than as its own message, so a
    short payload is not an error -- it is a client with no mods to declare.
    """
    body = m.HELLO.size
    rows = []
    # modCount rows and no more: the optional JPID / JPVR blocks follow them, and
    # reading every whole row in the payload (as this once did) would take a long
    # enough trailer for a mod. Older servers still do, which is why the game keeps
    # the trailer under one row (mp_proto.h MP_HELLO_VER_MAX).
    count = (len(payload) - body) // m.MODI.size
    if len(payload) >= body:
        count = min(count, m.HELLO.unpack_from(payload, 0)[5])

    for i in range(0, count):
        chunk = payload[body + i * m.MODI.size:body + (i + 1) * m.MODI.size]

        try:
            mod_id, version, enabled, _res = m.MODI.unpack(chunk)
        except Exception:
            break

        rows.append((mod_id.split(b"\0")[0].decode("latin1", "replace"),
                     version.split(b"\0")[0].decode("latin1", "replace"),
                     enabled))

    return rows


def mods_match(declared, required, versions, level, core=None):
    """The mod-check policy, exactly as the real host applies it, plus CORE mods.

    level 0 admits anyone. Above it:
      * every id in `core` MUST be enabled (the multiplayer suite: mp, carhacks,
        pedhacks). Optional modules are allowed beside them;
      * `bake` and its old id `d1cars` are tooling, never a join requirement,
        even if a config still lists them in core_mods or mods;
      * if `required` is non-empty, the enabled set must equal it exactly;
      * level 2 also compares the versions named in `versions`.

    `core` is what makes a dedicated server's preconfiguration meaningful: the
    core suite is mandatory, and a team can add optional modules (crumple, ...)
    without having to name every one of them. A server that names neither core
    nor required modules still matches everyone.
    """
    tooling = ("bake", "d1cars")

    if int(level) <= 0:
        return True

    have = set(mod_id for mod_id, _ver, enabled in declared
               if enabled and mod_id not in tooling)
    need = set(core or ()) - set(tooling)

    if need and not need <= have:
        return False

    if required and have != (set(required) - set(tooling)):
        return False

    if int(level) >= 2:
        for mod_id, version, enabled in declared:
            if (enabled and mod_id not in tooling and mod_id in versions
                    and versions[mod_id] != version):
                return False

    return True


def _is_command(line):
    """A chat COMMAND: '!' or '/' then a non-space, non-'!'/'/' character (the
    commands plugin's test, and the C host's MpChatIsCommand)."""
    return len(line) >= 2 and line[0] in "!/" and line[1] not in " !/"


def _mask_command(line):
    """The command word only, with any arguments shown as ****: "!login ****"."""
    parts = line.split(None, 1)
    return parts[0] + (" ****" if len(parts) > 1 else "")


def _chat_chunks(text, limit=95):
    """Split a server line into MP_CHAT-sized pieces (95 bytes + NUL), at spaces
    where possible and never inside a UTF-8 sequence. A line longer than one frame
    used to be cut at byte 95; now it goes out as several chat lines, which the
    client stacks and wraps -- same frame, same protocol."""
    data = text.encode()
    out = []
    while data:
        if len(data) <= limit:
            out.append(data)
            break
        cut = data.rfind(b" ", limit // 2, limit + 1)
        if cut <= 0:
            cut = limit
            while cut > 0 and (data[cut] & 0xC0) == 0x80:   # not mid-character
                cut -= 1
        out.append(data[:cut].rstrip())
        data = data[cut:].lstrip(b" ")
    return out


def _ink_bytes(value):
    """A config colour ("#RRGGBB", or "RRGGBB") as the three bytes the chat frame carries.

    Anything unparsable becomes the near-white a chat line uses by default: a typo in
    a config file should cost a colour, not the motd. Black is never a fallback --
    it would be invisible against the console.
    """
    text = (value or "").strip().lstrip("#")

    try:
        if len(text) >= 6:
            v = int(text[:6], 16)
            return ((v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF)
    except ValueError:
        pass

    return (240, 240, 240)


def normalise_host(value):
    """A registration host, cleaned: no scheme, no path, no port, no trailing dot.

    `advertise_host` is what players DIAL, and it is easy to fill in with the URL you
    have in your head -- "https://play.example.net/" -- which reads correctly and
    lists wrongly: the master stores what it is given, so the address in every
    client's browser becomes the scheme plus the name, and nothing can resolve it.
    Only what cannot be part of a host is removed; nothing is guessed.
    """
    host = (value or "").strip()

    if "://" in host:
        host = host.split("://", 1)[1]

    host = host.split("/", 1)[0].split("?", 1)[0].strip().rstrip(".")

    # a port here is a mistake the operator means well by -- the port has its own key
    if host.count(":") == 1:
        name, _, tail = host.partition(":")

        if tail.isdigit():
            host = name

    return host


def is_private_host(host):
    """Is this an address that only works on the machine that owns it?

    A dedicated server and a master on the SAME box is a good arrangement, and it
    has one trap: point `master` at 127.0.0.1 (the obvious choice, since it is right
    there) and the master honestly records the address it saw -- 127.0.0.1 -- and
    lists THAT to every internet client, none of whom can dial it.
    """
    host = (host or "").strip().lower()

    if host in ("localhost", "::1"):
        return True

    try:
        ip = socket.inet_aton(host)          # IPv4 only
    except OSError:
        return False                          # a name: the operator's business

    a, b = ip[0], ip[1]

    return (a == 0 or a == 127 or a == 10
            or (a == 172 and 16 <= b <= 31)
            or (a == 192 and b == 168))


def master_base(url):
    """The master's base URL, with the defaults filled in.

    A bare host used to become `http://host` and then connect to port 80, where
    nothing is listening -- so a config that looked right registered nowhere, and
    the failure was a connect error in a log nobody was reading. The scheme and the
    port are the master's defaults now; a URL that names either keeps it.
    """
    url = (url or "").strip().rstrip("/")

    if not url:
        return ""

    if "://" not in url:
        url = "http://" + url

    parts = urlsplit(url)
    host = parts.hostname or ""

    if not host:
        return ""

    return "%s://%s:%d" % (parts.scheme or "http", host, parts.port or 8100)


# ---------------------------------------------------------------------- the server
# Bytes on each client's link, both ways, for the scoreboard's rx / tx (MP_TAG_STATS):
# conn -> [rx, tx, since]. Every frame this server sends goes through _send.
_NET = {}


def _net(conn):
    st = _NET.get(conn)
    if st is None:
        st = _NET[conn] = [0, 0, time.monotonic()]
    return st


# The roster each connection was last SENT: (rows, previous rows, when it changed).
# A client cuts its traffic band from the last roster it got, not from who is
# connected right now, so the band check uses this (relay_peer_state).
_ROSTER_N = {}
_ROSTER_LOCK = threading.Lock()


def _send(conn, tag, payload=b""):
    m.send_frame(conn, tag, payload)
    _net(conn)[1] += m.ENV.size + len(payload)
    if tag == m.TAG["roster"] and payload:
        with _ROSTER_LOCK:
            cur = _ROSTER_N.get(conn)
            if cur is None or cur[0] != payload[0]:
                _ROSTER_N[conn] = (payload[0], cur[0] if cur else None, time.monotonic())


def _roster_counts(conn):
    """The roster sizes a client may be cutting its band from: the last one sent,
    and for ROSTER_REFRESH_S after a change the one before (frames already in
    flight when the new roster went out). None before any roster was sent."""
    with _ROSTER_LOCK:
        cur = _ROSTER_N.get(conn)
    if cur is None:
        return None
    if cur[1] is not None and time.monotonic() - cur[2] < ROSTER_REFRESH_S:
        return [cur[0], cur[1]]
    return [cur[0]]


def _ms32():
    """A millisecond clock in the PING tick's 32 bits (the host uses its own clock)."""
    return int(time.monotonic() * 1000) & 0xFFFFFFFF


class Dedicated:
    def __init__(self, cfg, log):
        self.cfg = cfg
        if "rules" not in cfg:
            resolve_rules(cfg, set(cfg))     # built from readable keys (tests, embedders)
        self.log = log
        self.lock = threading.Lock()
        self.clients = {}        # conn -> {"id", "name", "addr"}
        self.cars = {}           # playerId -> one MP_CARSTATE_ENTRY
        self.colors = {}         # playerId -> its MP_COLOR_ENTRY (8 bytes), the owner's word
        self.ped_models = {}     # playerId -> MP_PED_MODEL_* last reported by the owner
        self.stop = threading.Event()
        self.started = time.time()

        # Reported by the console. The beacon can be turned off from there (a LAN
        # you do not want to appear on) without stopping anything else, so the
        # loop reads this rather than the config value directly.
        self.beacon_on = bool(self.cfg["beacon"])

        # What the master_loop last managed, for 'master' to print. Kept as its own
        # small dict so the loop's local `token` stays local.
        self.master_state = {"base": "", "registered": False, "last": ""}

        # Plugins. `home` is where plugins_dir is resolved from; readvertise_evt asks
        # the master loop to re-register now (rules changed) instead of next beat.
        self.home = HERE
        self.config_path = cfg.get("_config_path") or ""
        self.readvertise_evt = threading.Event()
        self.plugins = PluginManager(self)
        self.plugins.load()

        self.console = None
        self.started = time.time()

    # -- helpers
    @property
    def max_players(self):
        return int(self.cfg["max_players"])

    @property
    def port(self):
        return int(self.cfg["port"])

    @property
    def city(self):
        return int(self.cfg["city"])

    @property
    def arena(self):
        return int(self.cfg["arena"])

    @property
    def map_mode(self):
        return MAP_MODE_CITY if self.cfg.get("map_mode", MAP_MODE_MP) == MAP_MODE_CITY else MAP_MODE_MP

    @property
    def map_shape(self):
        return 1 if self.map_mode == MAP_MODE_MP else 0

    def session_spare(self):
        """MP_SESSION.spare: bit 0 is map shape, bits 1.. are rules, bit 8 is arena."""
        arena = self.arena if self.map_shape else 0
        return ((self.map_shape & 1) | ((int(self.cfg["rules"]) & 0x7F) << 1)
                | ((arena & 1) << 8))

    # -- the plugin-facing surface (dedi/plugins.py ServerAPI calls these)
    def player_views(self):
        with self.lock:
            rows = list(self.clients.items())
        return sorted((Player(c, i) for c, i in rows), key=lambda p: p.id)

    def send_to(self, conn, tag, payload):
        _send(conn, tag, payload)

    def send_server_chat(self, text, color=None, conn=None):
        """Chat line(s) in the server's own voice (player id 0xFF), to one
        connection or everyone. A colour rides in the frame's reserved bytes, as
        the motd's does."""
        ink = _ink_bytes(color) if color else (0, 0, 0)
        for line in str(text).split("\n"):
            for piece in _chat_chunks(line) or [b" "]:
                frame = m.CHAT.pack(0xFF, ink[0], ink[1], ink[2], piece)
                if conn is None:
                    self.broadcast(frame, m.TAG["chat"])
                else:
                    try:
                        self.send_to(conn, m.TAG["chat"], frame)
                    except OSError:
                        pass

    def set_rules(self, **rules):
        for k, v in rules.items():
            if k not in RULE_KEYS:
                raise KeyError("unknown rule %r" % k)
            self.cfg[k] = v
        resolve_rules(self.cfg, set(RULE_KEYS))
        self.log.info("rules now: %s (from the next level load)" % rules_text(int(self.cfg["rules"])))
        self.readvertise()
        return rules_text(int(self.cfg["rules"]))

    def readvertise(self):
        self.readvertise_evt.set()

    def set_session(self, time_of_day=None, weather=None):
        """Time of day / weather by name or number; from the next level load."""
        if time_of_day is not None:
            i = _named_index(time_of_day, TIMES_OF_DAY, -1)
            if i < 0:
                raise ValueError("time of day is one of %s" % "/".join(TIMES_OF_DAY))
            self.cfg["time_of_day"] = TIMES_OF_DAY[i]
        if weather is not None:
            i = _named_index(weather, WEATHERS, -1)
            if i < 0:
                raise ValueError("weather is one of %s" % "/".join(WEATHERS))
            self.cfg["weather"] = WEATHERS[i]
        self.log.info("session now: %s, %s (from the next level load)"
                      % (self.cfg["time_of_day"], self.cfg["weather"]))
        self.readvertise()
        return "%s, %s" % (self.cfg["time_of_day"], self.cfg["weather"])

    def set_city(self, city):
        city = int(city)
        if not 0 <= city <= 3:
            raise ValueError("city is 0..3")
        self.cfg["city"] = city
        self.log.info("city now %d (new joiners load it)" % city)
        self.readvertise()
        return city

    def set_map_mode(self, mode):
        mode = str(mode).strip().lower()
        if mode not in (MAP_MODE_CITY, MAP_MODE_MP):
            raise ValueError("map mode is city or mp")
        self.cfg["map_mode"] = mode
        self.log.info("map mode now %s (new joiners load it)" % mode)
        self.readvertise()
        return mode

    def set_arena(self, arena):
        arena = int(arena)
        if not 0 <= arena <= 1:
            raise ValueError("arena is 0..1")
        self.cfg["arena"] = arena
        self.log.info("multiplayer map now %d (new joiners load it)" % arena)
        self.readvertise()
        return arena

    def save_config_keys(self, keys):
        """Write these cfg keys back into the config file, keeping every other key
        as the operator wrote it. Atomic (temp file + replace). Returns the path."""
        path = self.config_path or os.path.join(HERE, CONFIG_NAME)
        data = {}
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        for k in keys:
            data[k] = self.cfg.get(k)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
        os.replace(tmp, path)
        self.log.info("saved %s to %s" % (", ".join(keys), path))
        return path

    def player_count(self):
        with self.lock:
            return len(self.clients)

    def free_id(self):
        for i in range(1, self.max_players):
            if all(c["id"] != i for c in self.clients.values()):
                return i
        return None

    def carstate_union(self, frame):
        with self.lock:
            rows = list(self.cars.items())
        hdr = m.CARSTATE.pack(frame & 0xFFFFFFFF, len(rows), 0, 0, 0)
        return hdr + b"".join(e for _, e in rows)

    def roster_bytes(self):
        """MP_ROSTER for the clients connected right now -- who is in the match.

        A client learns its PEERS ONLY from this. mp_session.c's MpHandleRoster
        adopts any player it does not already know and, when
        MP_ROSTER_FLAG_CAR_READY is set, builds that player's car; without a roster
        every client knows just the server's phantom player 0 and itself, which is
        the symptom this server had: "you can see yourself and the host, but not the
        other players".

        The server gets no row of its own. The clients invent their player 0 without
        being told, and naming it here would start changing what that phantom is.

        A player's car comes from the carstate rows the server already keeps (the
        same model/modelCity the peers are driving); 0xFF while we have not seen one
        yet, which is "on foot" -- so a client still loading is listed, named, and
        simply given no car until its first carstate lands.
        """
        with self.lock:
            rows = []
            for info in self.clients.values():
                car = self.cars.get(info["id"])
                model, model_city, ready = 0xFF, 0xFF, 0
                left_model, left_city = 0xFF, 0xFF
                palette = info.get("palette", 0)       # HELLO / JPCC until their carstate
                pick = info.get("car")
                if pick is not None and pick[0] != 0xFF:
                    # the car they PICKED (JPCC), before any carstate: the host lists
                    # it with CAR_READY (MpHandleCar -> carConfirmed) so peers build it
                    model, model_city = pick
                    ready = m.ROSTER_FLAG_CAR_READY
                if car is not None and len(car) == m.CARSTATE_ENTRY.size:
                    # the first five fields of the row: pid, flags, palette, model, modelCity
                    fields = m.CARSTATE_ENTRY.unpack_from(car, 0)
                    _pid, flags, palette, model, model_city = fields[:5]
                    ready = m.ROSTER_FLAG_CAR_READY
                    # on foot beside a parked car (MP_CARSTATE_LEFT_CAR): name it, as the
                    # in-game host's roster does, so a late joiner sees them on foot
                    if model == 0xFF and flags & m.CARSTATE_LEFT_CAR:
                        left_model, left_city = fields[-4], fields[-3]
                rows.append((info["id"], info["name"], model, model_city, palette, ready,
                             info.get("ping", 0),
                             self.ped_models.get(info["id"], m.PED_MODEL_TANNER),
                             left_model, left_city))
        rows.sort(key=lambda r: r[0])

        out = bytearray(m.ROSTER.pack(len(rows), 0, 0, 0))
        for pid, name, model, model_city, palette, ready, ping, ped_model, left_model, left_city in rows:
            out += m.ROSTER_ENTRY.pack(
                pid & 0xFF, 0, model & 0xFF, model_city & 0xFF, ready,
                ped_model & 0xFF,                     # MP_PED_MODEL_*: the late-join snapshot
                min(int(ping), 0xFFFF),               # ping: our PING -> their PONG round trip
                palette & 0xFFFF,
                left_model & 0xFF, left_city & 0xFF,  # leftModel/leftModelCity (proto 20): from the owner's carstate
                name.encode("latin1", "replace")[: m.ROSTER_NAME_MAX - 1])
        return bytes(out)

    def _send_roster_if_due(self, conn, last, pid):
        """(socket still alive, new timestamp) -- the roster when its cadence elapses.

        Called from BOTH ways round the receive loop on purpose. Putting it only in
        the timeout branch looked right and was wrong: a client that is DRIVING sends
        a carstate every frame, so its socket never times out and it would never be
        told a peer had joined. Only the joiner saw anyone, which is exactly the
        asymmetry that showed up here -- "added 2 remote player car(s)" on the second
        client and 1 on the first.
        """
        now = time.time()
        if now - last < ROSTER_REFRESH_S:
            return True, last
        try:
            _send(conn, m.TAG["roster"], self.roster_bytes())
            # ...and the colour table on the same cadence, as the host's
            # MpSendColors(1) every 120 frames: how a late joiner learns everyone
            table = relay.color_table(self)
            if table:
                _send(conn, m.TAG["color"], table)
            # ...and everyone's link stats, as the host sends MP_TAG_STATS with it
            _send(conn, m.TAG["stats"], self.stats_bytes())
            # ...and a PING, as the host's keepalive does: the client echoes the tick
            # in a PONG, and that round trip is the roster's `ping` (MpPingForPlayer)
            _send(conn, m.TAG["ping"], struct.pack("<I", _ms32()))
        except OSError:
            return False, now
        except Exception as e:
            # a roster we cannot build must not cost the player their connection
            self.log.debug("roster refresh failed for player %d: %s" % (pid, e))
        return True, now

    def stats_bytes(self):
        """MP_STATS: each client's link to this server -- rx = bytes/s we receive
        from them, tx = bytes/s we send them, ping = our measured round trip. Loss
        is the host's "frames with nothing from them", which a frameless server
        cannot measure, so it says unknown (the game then shows '--')."""
        now = time.monotonic()
        with self.lock:
            items = sorted((info["id"], info.get("ping", 0), _NET.get(c)) for c, info in self.clients.items())
        out = bytearray(m.STATS.pack(0))
        n = 0
        for pid, ping, st in items:
            if st is None:
                continue
            secs = max(now - st[2], 0.001)
            out += m.STATS_ENTRY.pack(pid & 0xFF, m.STATS_LOSS_UNKNOWN, min(int(ping), 0xFFFF),
                                      min(int(st[0] / secs), 0xFFFFFFFF), min(int(st[1] / secs), 0xFFFFFFFF))
            n += 1
        out[0] = n
        return bytes(out)

    def note_car_pick(self, conn, payload):
        """JPCC, the car a player picked: kept for the roster, which the caller
        then sends to everyone at once -- the host's MpHandleCar does the same
        (record, then MpHostSendRoster), so the car shows without waiting for the
        player's first carstate. Returns True when it was a valid pick."""
        if len(payload) < m.CAR_PICK.size:
            return False
        model, city = m.CAR_PICK.unpack_from(payload, 0)
        with self.lock:
            info = self.clients.get(conn)
            if info is None:
                return False
            # proto 21: 0..10 a stock city, 0x80..0xFE a runtime bank spelled by its NAME
            # code (carhacks decides; the server only relays it), 0xFF the session's own.
            info["car"] = (model, city if (city < m.CITY_COUNT or m.CITY_WIRE_CODE_FIRST <= city <= m.CITY_WIRE_CODE_LAST) else 0xFF)
            if len(payload) >= 4 and payload[3] == 1:
                info["palette"] = payload[2]           # MP_CAR reserved[0], flagged by [1]
        return True

    def note_pong(self, conn, payload):
        """A client's PONG to our PING: the round trip in ms, kept for the roster.
        Returns it, or None for a frame that is not an answer to us."""
        if len(payload) < 4:
            return None
        rtt = (_ms32() - struct.unpack_from("<I", payload, 0)[0]) & 0xFFFFFFFF
        if rtt > 60000:
            return None
        with self.lock:
            info = self.clients.get(conn)
            if info is not None:
                info["ping"] = rtt
        return rtt

    def broadcast(self, payload, tag, skip=None):
        with self.lock:
            conns = [c for c in self.clients if c is not skip]
        for c in conns:
            try:
                _send(c, tag, payload)
            except OSError:
                pass

    def relay_peer_state(self, conn, tag, payload, pid):
        """Forward an owner -> peers state frame, verbatim, to everyone else.

        On-foot poses (JPPD) and replicated traffic/police (JPTF) are sent by the
        machine that owns them to the HOST, and the in-game host relays them as-is
        to every other connection (mp_session.c MpHandlePedState / MpHandleTraffic
        -> MpHostRelay). This server dropped both, so on a dedicated server nobody
        saw a player on foot or another machine's traffic. The server keeps no copy:
        neither has a late-join snapshot in the game either.

        A pose may only describe its sender: a JPPD row naming another player id
        is a spoof (or a confused client) and the frame is dropped. Returns True
        when relayed."""
        if tag == m.TAG["ped"]:
            try:
                count = m.PEDSTATE.unpack_from(payload, 0)[0]
                rows = [payload[m.PEDSTATE.size + i * m.PEDSTATE_ENTRY.size]
                        for i in range(count)]
                if count < 1 or len(payload) < m.PEDSTATE.size + count * m.PEDSTATE_ENTRY.size \
                        or any(r != pid for r in rows):
                    raise ValueError
            except (ValueError, IndexError, struct.error):
                self.log.debug("player %d: dropping a malformed or foreign on-foot frame" % pid)
                return False
            # The pose carries the owner's character too (entry byte 2). Keep it for
            # the roster snapshot, so a joiner gets the model even while this player
            # is in a car and sending no poses. The frame itself still goes out
            # verbatim -- peers read the same field.
            with self.lock:
                self.ped_models[pid] = payload[m.PEDSTATE.size + 2]
        elif tag == m.TAG["traffic"]:
            # A client may only speak for the slots of its OWN band (mp_session.c
            # MpHandleTraffic): the band as the sender computes it, from its player
            # count (the rows of the last roster it was sent: no player 0 here) and
            # never below pid + 1.
            try:
                count = m.TRAFFIC.unpack_from(payload, 0)[1]
                count = min(count, m.MAX_CARS,
                            (len(payload) - m.TRAFFIC.size) // m.TRAFFIC_ENTRY.size)
                counts = _roster_counts(conn)
                if counts is None:
                    with self.lock:
                        counts = [len(self.clients)]
                slots = [payload[m.TRAFFIC.size + i * m.TRAFFIC_ENTRY.size] for i in range(count)]
                if not any(all(s < m.MAX_CARS and first >= 0 and first <= s <= last for s in slots)
                           for first, last in (relay.client_traffic_band(pid, n) for n in counts)):
                    raise ValueError
            except (ValueError, IndexError, struct.error):
                self.log.debug("player %d: dropping a traffic frame outside its band" % pid)
                return False
        self.broadcast(payload, tag, skip=conn)
        return True

    def _chat(self, conn, payload, pid, name):
        """Print one chat line to the operator console, then relay it.

        The id inside the frame is the SENDER'S CLAIM, and a claim is all it is:
        the connection is who is talking. It is stamped here BEFORE the relay, so
        the other seats see the real speaker too -- the same rule the C host
        applies on its own chat path.

        Control characters are stripped, because this line goes to a terminal: a
        peer that puts an escape sequence or a newline in a message could
        otherwise forge console rows (or paint the operator's terminal).
        """
        try:
            _claimed, _r0, _r1, _r2, text = m.CHAT.unpack_from(payload, 0)
        except struct.error:
            self.log.debug("player %d '%s': ignoring a malformed chat frame" % (pid, name))
            return

        line = text.split(b"\0")[0].decode("latin1", "replace")
        line = "".join(ch if ch.isprintable() else " " for ch in line).strip()

        if not line:
            return

        # Plugins first: a command ("!help") is consumed and never relayed.
        with self.lock:
            info = self.clients.get(conn)
        consumed = info is not None and self.plugins.chat(Player(conn, info), line)
        if consumed or _is_command(line):
            # Never relayed, never logged in full: "!login hunter2" is a password.
            # Even with the commands plugin missing or disabled, a command-shaped
            # line stays with its sender instead of reaching every seat.
            self.log.info("[cmd] %s: %s" % (name, _mask_command(line)))
            if not consumed and info is not None:
                self.send_server_chat("commands are not available on this server", conn=conn)
            return

        # An admin's line carries MP_CHAT_MARK_ADMIN (mp_proto.h) in the ink bytes:
        # the client draws "[Admin] name" from it (older clients ignore it).
        admin = info is not None and bool(info.get("admin"))
        self.log.info("[chat] %s%s: %s" % ("[Admin] " if admin else "", name, line))

        out = m.CHAT.pack(pid, 1 if admin else 0, 0, 0, line.encode("latin1", "replace")[:95])
        # To EVERYONE, the sender included. The client never prints its own line:
        # MpSendChat (mp_session.c) sends it to the host and waits for the host's
        # echo, exactly as a game host republishes "to everyone (including the
        # sender)". Skipping the sender here meant a player on a dedicated server
        # never saw anything they typed -- alone on the server, chat looked dead.
        self.broadcast(out, m.TAG["chat"])

    # -- one client
    def serve(self, conn, addr):
        who = "%s:%d" % (addr[0], addr[1])
        try:
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        conn.settimeout(self.cfg["idle_drop_s"] or 1.0)

        try:
            tag, payload = m.recv_frame(conn)
        except (OSError, socket.timeout):
            conn.close()
            return
        if tag != m.TAG["hello"]:
            # DEBUG, not a warning: a bare TCP connect is a health probe, a
            # reachability check (the master runs one every few seconds), or a port
            # scan -- none of which is an error, and warning about them buries the
            # lines that matter.
            self.log.debug("%s: connected without a HELLO (tag %r), dropping" % (who, tag))
            conn.close()
            return
        try:
            # the four tail bytes are (modCount, reserved[3]) -- reading them
            # shifted by one is why every join logged "mods=0"
            _proto, _sdk, build, _sp, name32, modc, _a, _b, _c = m.HELLO.unpack_from(payload, 0)
        except Exception:
            self.log.warning("%s: malformed HELLO, dropping" % who)
            conn.close()
            return

        name = name32.split(b"\0")[0].decode("latin1", "replace") or "Player"

        # The manifest rides after the hello header, modc rows of it.
        mods = parse_manifest(payload)

        # -- the wire has to agree before anything else means anything: a client on
        # a different protocol would misread every frame this server sends it, so it
        # is refused the way the real host refuses it, with the reason readable.
        if _proto != m.PROTO or _sdk != m.SDK:
            self.log.warning("%s: refused, version mismatch (proto %d/%d, sdk %d/%d)"
                             % (who, _proto, m.PROTO, _sdk, m.SDK))
            self._reject(conn, 2, "game/protocol version mismatch")
            return

        # -- and the mod list, if this server enforces one
        matched = mods_match(mods, self.cfg["mods"], self.cfg["mod_versions"],
                             self.cfg["mod_check"], self.cfg.get("core_mods", []))

        if not matched:
            self.log.warning("%s: refused, mod list does not match (declared: %s; "
                             "required core: %s; required exact: %s)"
                             % (who, ", ".join(sorted(x[0] for x in mods if x[2])) or "none",
                                ", ".join(sorted(self.cfg.get("core_mods", []))) or "none",
                                ", ".join(sorted(self.cfg["mods"])) or "any"))
            self._reject(conn, 3, "mod list does not match the server")
            return

        if mods:
            self.log.info("%s declares mods: %s"
                          % (who, ", ".join("%s %s" % (x[0], x[1]) for x in mods if x[2])))

        refused_full = False

        with self.lock:
            pid = self.free_id()
            if pid is None:
                # len(self.clients), not self.player_count(): we are INSIDE the
                # lock, and player_count() takes it too -> a non-reentrant Lock
                # would deadlock this thread with the lock held forever.
                refused_full = True
            else:
                self.clients[conn] = {"id": pid, "name": name, "addr": who,
                                      "player_id": m.parse_player_id(payload),
                                      "version": m.parse_hello_version(payload),
                                      "mods_digest": m.mods_digest(mods),
                                      "palette": _b}       # HELLO reserved[1]: their car palette

        if refused_full:
            # The real host answers a full server with a REJECT alone -- a WELCOME
            # here would tell the client it got in. _reject half-closes, which is
            # what lets the reason reach the client at all (TESTING.md, F3).
            self.log.warning("refused %s: server is full (%d/%d)"
                             % (who, self.player_count(), self.max_players))
            self._reject(conn, 1, "server is full")
            return

        self.log.info("player %d '%s' joined from %s (mods=%d, build %#06x, "
                      "modsMatched=%d)"
                      % (pid, name, who, modc, build, matched))

        seed = int(time.time()) & 0xFFFFFFFF

        # The roster goes BEFORE the welcome. mp_test.py records the order as
        # load-bearing: a live joiner has to know who else is in the match before it
        # spawns cars, because the spawn walks the player list.
        try:
            _send(conn, m.TAG["roster"], self.roster_bytes())
        except Exception as e:
            # A roster we cannot build must NOT cost the player their connection --
            # they simply arrive without a peer list, which is what this server did
            # before it had one at all.
            self.log.warning("could not send the roster to %s: %s" % (who, e))
        # spare carries the map shape (bit 0), the session rules (bits 1..: mp_proto.h,
        # MpHandleStart reads (spare >> 1) & 0xff) and which of the city's two maps
        # (bit 8). A 0 for the rules, and a 0 in the welcome's rules byte, meant every
        # client adopted "no rules": cops OFF, whatever this server's config said.
        sess = m.SESSION.pack(0, self.city, time_of_day_index(self.cfg), weather_index(self.cfg),
                              seed, max(2, self.player_count() + 1), 1, self.session_spare())
        try:
            # running=1: a dedicated server IS a match in progress. It said 0, and
            # the client takes its "the host has STARTed" branch only when this is
            # set -- so a joiner was never offered the CAR SELECT and went straight
            # into the session in whatever vehicle the module defaulted to. 0 is
            # right for a host still sitting in its lobby; it is never right here.
            _send(conn, m.TAG["welcome"],
                         self._welcome(pid, running=1 if self.cfg["live"] else 0,
                                       matched=matched, seed=seed))
            _send(conn, m.TAG["start"], sess)
        except OSError:
            pass

        # THE MOTD, and only to THIS connection: it is a greeting, not an
        # announcement. It goes down the chat channel because that is already the
        # client's own "SERVER:" voice (see cmd_say): player id 0xFF matches no
        # player, so the client prints the text with no name attached to it.
        # The text is the MESSAGE ONLY: the client labels a speaker with no player row
        # as "SERVER" itself, so a prefix here would read "SERVER: SERVER: ...".
        motd = (self.cfg.get("motd") or "").strip()

        if motd:
            ink = _ink_bytes(self.cfg.get("motd_color"))
            try:
                for piece in _chat_chunks(motd):
                    _send(conn, m.TAG["chat"],
                                 m.CHAT.pack(0xFF, ink[0], ink[1], ink[2], piece))
            except OSError:
                pass
            self.log.debug("sent the motd to %s" % who)

        with self.lock:
            joined = self.clients.get(conn)
        if joined is not None:
            self.plugins.call("on_player_join", Player(conn, joined))

        # Poll fast so we can keep the link fresh from OUR side too: a dedicated
        # server should not depend on the client to prove the link is alive.
        conn.settimeout(1.0)
        silent = 0
        idle_drop = float(self.cfg["idle_drop_s"])
        info = None
        last_roster = 0.0

        # The whole loop is wrapped so the cleanup below ALWAYS runs: a malformed
        # frame (a bad CARSTATE header) must not unwind the thread and strand the
        # socket open with its slot still taken.
        try:
            while not self.stop.is_set():
                try:
                    tag, payload = m.recv_frame(conn)
                    if tag is not None:
                        _net(conn)[0] += m.ENV.size + len(payload)
                except socket.timeout:
                    silent += 1
                    # Send our own keepalive PING and only give the client up after
                    # `idle_drop_s` of real silence. Without this a quiet client (a
                    # lobby, a load) would be dropped by our own timeout.
                    if idle_drop and silent >= idle_drop:
                        self.log.warning("player %d '%s' timed out (%.0fs silent)"
                                         % (pid, name, idle_drop))
                        break
                    try:
                        _send(conn, m.TAG["ping"],
                                     struct.pack("<I", int(time.time() * 1000) & 0xFFFFFFFF))
                    except OSError:
                        break
                    # The roster, on the host's own cadence (mp_session.c refreshes
                    # it every 120 frames = ~2s). This is how a client learns a peer
                    # joined or left, and how a peer's car appears once its first
                    # carstate has landed.
                    alive, last_roster = self._send_roster_if_due(conn, last_roster, pid)
                    if not alive:
                        break
                    continue
                except Exception:
                    break
                if tag is None:
                    break
                silent = 0

                # the running client's half of the cadence (see the helper): it is
                # never idle, so the timeout branch alone would never reach it
                alive, last_roster = self._send_roster_if_due(conn, last_roster, pid)
                if not alive:
                    break

                if tag == m.TAG["carstate"]:
                    try:
                        with self.lock:
                            _f, count, _a, _b, _c = m.CARSTATE.unpack_from(payload, 0)
                            # bound the loop by what actually arrived: a bogus count
                            # must not spin, and a short frame must not read past it
                            avail = (len(payload) - m.CARSTATE.size) // m.CARSTATE_ENTRY.size
                            for i in range(min(count, max(0, avail))):
                                off = m.CARSTATE.size + i * m.CARSTATE_ENTRY.size
                                e = payload[off:off + m.CARSTATE_ENTRY.size]
                                # a row may only describe its sender (as for JPPD)
                                if len(e) == m.CARSTATE_ENTRY.size and e[0] == pid:
                                    self.cars[e[0]] = e
                    except Exception:
                        # a malformed frame is this connection's problem, not the
                        # server's: skip it and keep serving
                        self.log.debug("player %d '%s': ignoring a malformed carstate frame"
                                       % (pid, name))
                        continue
                    self.broadcast(self.carstate_union(int(time.time() * 30)),
                                   m.TAG["carstate"], skip=conn)
                elif tag in (m.TAG["ped"], m.TAG["traffic"]):
                    self.relay_peer_state(conn, tag, payload, pid)
                elif tag == m.TAG["hit"]:
                    relay.hit(self, conn, pid, payload)
                elif tag == m.TAG["color"]:
                    relay.color(self, conn, pid, payload)
                elif tag == m.TAG["channel"]:
                    relay.channel(self, conn, pid, payload)
                elif tag == m.TAG["chat"]:
                    self._chat(conn, payload, pid, name)
                elif tag == m.TAG["ping"]:
                    # Liveness. Echo the tick; with no PONG the client's last-receive
                    # clock stops advancing and it drops itself at its idle timeout.
                    try:
                        _send(conn, m.TAG["pong"], payload or b"\x00\x00\x00\x00")
                    except OSError:
                        break
                elif tag == m.TAG["car"]:
                    if self.note_car_pick(conn, payload):
                        self.broadcast(self.roster_bytes(), m.TAG["roster"])
                elif tag == m.TAG["pong"]:
                    self.note_pong(conn, payload)
                elif tag == m.TAG["leave"]:
                    break
        finally:
            with self.lock:
                info = self.clients.pop(conn, None)
                if info:
                    self.cars.pop(info["id"], None)
                    self.colors.pop(info["id"], None)
                    self.ped_models.pop(info["id"], None)
                _NET.pop(conn, None)
                with _ROSTER_LOCK:
                    _ROSTER_N.pop(conn, None)
            if info:
                self.plugins.call("on_player_leave", Player(conn, info))
                self.log.info("player %d '%s' left (%d/%d)"
                              % (info["id"], info["name"], self.player_count(), self.max_players))
                # Tell the others NOW: a client takes the leaver's Tanner and car
                # out of the world when the roster stops naming them, and waiting
                # for the next cadence left both standing for seconds.
                try:
                    self.broadcast(self.roster_bytes(), m.TAG["roster"])
                except Exception as e:
                    self.log.debug("leave roster broadcast failed: %s" % e)
            try:
                conn.close()
            except OSError:
                pass

    def _reject(self, conn, reason, text):
        """Refuse, and let the client READ the reason.

        The old path sent the frame and closed the socket at once, so the peer often
        got 0 bytes back -- "a refused client is told nothing" (TESTING.md, F3). The
        real host half-closes, lets the peer drain, then closes; this does the same,
        and every refusal in this file goes through it.
        """
        try:
            _send(conn, m.TAG["reject"], m.REJECT.pack(reason, 0, 0, 0, text.encode()))
        except OSError:
            pass

        try:
            conn.shutdown(socket.SHUT_WR)     # half-close: our bytes still arrive
        except OSError:
            pass

        try:
            conn.settimeout(1.0)
            while conn.recv(4096):            # drain what the peer is still sending
                pass
        except OSError:
            pass

        try:
            conn.close()
        except OSError:
            pass

    def _welcome(self, pid, running, matched=1, seed=0):
        # 15 values: playerId, maxPlayers, modsEnforced, modsMatched, running,
        # subGame, mpLevel, arena, gamemode, city, timeOfDay, weather, seed,
        # hostCar, rules  (mp_proto.h MP_WELCOME, 18 bytes since v11).
        # mpLevel carries the requested map shape: 0 = full city, 1 = multiplayer.
        # Arena only applies to multiplayer maps.
        return m.WELCOME.pack(pid, self.max_players, int(self.cfg["mod_check"]),
                              1 if matched else 0, running, 0, self.map_shape,
                              self.arena if self.map_shape else 0,
                              int(self.cfg["gamemode"]), self.city,
                              time_of_day_index(self.cfg), weather_index(self.cfg),
                              seed, 0xFF, int(self.cfg["rules"]) & 0xFF)

    # -- UDP beacon (LAN discovery)
    def beacon_loop(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        host = self.cfg["name"].encode()[:31] + b"\0" * 32
        host = host[:32]
        while not self.stop.is_set():
            if not self.beacon_on:
                self.stop.wait(self.cfg["beacon_ms"] / 1000.0)
                continue

            pkt = m.BEACON.pack(m.UDP_MAGIC, m.PROTO, self.port, host,
                                self.player_count(), self.max_players,
                                int(self.cfg["gamemode"]), 0, self.city,
                                1 if self.cfg["live"] else 0, 0,
                                int(self.cfg["rules"]))
            try:
                # to the DISCOVERY port, never to our own session port: the session port
                # travels INSIDE the beacon, and a browser listens on the fixed one
                s.sendto(pkt, ("255.255.255.255", m.DISCOVERY_PORT))
            except OSError:
                pass
            self.stop.wait(self.cfg["beacon_ms"] / 1000.0)
        s.close()

    # -- master discovery registration
    def master_loop(self):
        base = master_base(self.cfg["master"])
        token = None
        interval = float(self.cfg["master_interval_s"])
        timeout = float(self.cfg["master_timeout_s"])
        backoff = 2.0

        def post(path, body):
            req = urllib.request.Request(base + path, data=json.dumps(body).encode(),
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, json.loads(r.read().decode())

        while not self.stop.is_set():
            try:
                if token is None:
                    # Where players actually reach us, when that is not where the master
                    # sees us. Both halves matter behind NAT: the address it would record
                    # is private, and a remapping router can hand out a public port that
                    # differs from our session port.
                    adv = {}
                    if self.cfg["advertise_host"]:
                        adv["advertiseHost"] = self.cfg["advertise_host"]
                    if int(self.cfg["advertise_port"]):
                        adv["advertisePort"] = int(self.cfg["advertise_port"])

                    st, body = post("/v1/register", {
                        "name": self.cfg["master_name"] or self.cfg["name"],
                        "port": self.port, "city": self.city,
                        "gamemode": int(self.cfg["gamemode"]),
                        # the same packed byte the beacon carries, so a browser
                        # can name the mode from either source
                        "rules": int(self.cfg["rules"]),
                        "players": self.player_count(), "maxPlayers": self.max_players,
                        "inProgress": 1 if self.cfg["live"] else 0,
                        # whether this server checks a client's mod manifest, so a
                        # browser can warn before anyone tries to join
                        "modsEnforced": int(self.cfg["mod_check"]),
                        "protoVersion": m.PROTO, "sdkVersion": m.SDK,
                        **adv,
                    })
                    if st not in (200, 201):
                        raise OSError("register returned %s" % st)
                    token = body["token"]
                    self.master_state.update(base=base, registered=True,
                                             last="registered at %s"
                                             % time.strftime("%H:%M:%S"))
                    listed = str(body.get("host") or "")

                    # The master lists whatever address it saw us from. Behind a
                    # co-hosted master that is loopback or a private address unless
                    # `master` names something public -- and then the listing is
                    # useless to the internet while looking perfectly healthy here.
                    if listed and not self.cfg["advertise_host"] and is_private_host(listed):
                        why = ("loopback" if listed.startswith("127.") or listed == "localhost"
                               else "a private address")
                        msg = ("listed as %s:%d, which is %s: internet clients cannot "
                               "reach that. Point master at a PUBLIC address (so the "
                               "peer address it records is the right one), or set "
                               "advertise_host to the public name"
                               % (listed, self.port, why))
                        self.log.warning(msg)

                        if self.console is not None:
                            self.console.say("WARNING: " + msg)

                    self.log.info("registered with master %s as %s:%d"
                                  % (base, body.get("host"), body.get("port")))
                    backoff = 2.0
                else:
                    try:
                        post("/v1/heartbeat", {"token": token, "players": self.player_count()})
                    except urllib.error.HTTPError as e:
                        if e.code == 404:      # expired / master restarted -> re-register
                            self.log.warning("master forgot us; re-registering")
                            token = None
                            continue
                        raise
                # sleep a beat -- or less, when the rules changed and the listing
                # must say so now (readvertise): re-registering replaces our entry
                if self.readvertise_evt.wait(interval) and not self.stop.is_set():
                    self.readvertise_evt.clear()
                    token = None
            except (OSError, ValueError, KeyError) as e:
                self.master_state.update(base=base, registered=False,
                                         last="unreachable: %s" % e)
                self.log.warning("master %s unreachable (%s); retrying in %.0fs"
                                 % (base, e, backoff))
                self.stop.wait(backoff)
                backoff = min(backoff * 2, 60.0)
                token = None

        if token is not None:
            try:
                post("/v1/unregister", {"token": token})
                self.master_state.update(registered=False, last="unregistered")
                self.log.info("unregistered from master")
            except OSError:
                pass

    # -- lifecycle
    # -- console ----------------------------------------------------------
    def console_commands(self):
        """The operator's command table.

        `help` is generated from this by the Console, so a command cannot exist
        without being listed -- and every handler takes the rest of the typed line
        as one string, so quoting is the operator's problem, not a parser's.
        """
        return [
            ("status", "name, port, city, mode, players, uptime, beacon, master", self.cmd_status),
            ("list", "connected players: id, name, address, how long", self.cmd_list),
            ("say", "broadcast a line into every player's console: say <text>", self.cmd_say),
            ("kick", "drop a player, telling them: kick <id> [reason]  ('list' shows ids)", self.cmd_kick),
            ("beacon", "LAN beacon: beacon [on|off], or its state", self.cmd_beacon),
            ("master", "discovery-server registration state", self.cmd_master),
            ("stop", "close the server (unregisters from the master)", self.cmd_stop),
            ("help", "list these commands", self.cmd_help),
            ("plugins", "loaded and disabled plugins", self.cmd_plugins),
        ] + self.plugins.console_entries({"status", "list", "say", "kick", "beacon",
                                          "master", "stop", "help", "plugins"})

    def cmd_plugins(self, _rest):
        rows = ["loaded:   %s" % (", ".join(n for n, _ in self.plugins.plugins) or "none")]
        for n, why in sorted(self.plugins.disabled.items()):
            rows.append("disabled: %s (%s)" % (n, why))
        return "\n".join(rows)

    def cmd_help(self, _rest):
        return self.console.help_text() if self.console is not None else ""

    def cmd_status(self, _rest):
        adv = ""
        if self.cfg["advertise_host"] or int(self.cfg["advertise_port"]):
            adv = " (advertised as %s:%d)" % (self.cfg["advertise_host"],
                                              int(self.cfg["advertise_port"]) or self.port)
        return "\n".join([
            "name:      %s" % self.cfg["name"],
            "session:   TCP/%d%s" % (self.port, adv),
            "city:      %d" % self.city,
            "map mode:  %s" % ("multiplayer" if self.map_shape else "single-player city"),
            "arena:     %d (of the city's two multiplayer maps)" % self.arena,
            "gamemode:  %d" % int(self.cfg["gamemode"]),
            "rules:     %s" % rules_text(int(self.cfg["rules"])),
            "time:      %s, %s" % (TIMES_OF_DAY[time_of_day_index(self.cfg)],
                                   WEATHERS[weather_index(self.cfg)]),
            "players:   %d/%d" % (self.player_count(), self.max_players),
            "uptime:    %s" % duration(time.time() - self.started),
            "beacon:    %s" % (("every %dms to UDP/%d"
                                % (int(self.cfg["beacon_ms"]), m.DISCOVERY_PORT))
                               if self.beacon_on else "off"),
            "master:    %s" % (self.master_state["last"] or "not configured"),
        ])

    def cmd_list(self, _rest):
        with self.lock:
            rows = sorted((c["id"], c["name"], c["addr"],
                           duration(time.time() - c.get("since", time.time())))
                          for c in self.clients.values())

        if not rows:
            return "no players connected"

        return "\n".join("%3d  %-20s %-21s %s" % r for r in rows)

    def cmd_say(self, rest):
        if not rest:
            return "say what?  (say <text>)"

        # 0xFF is not a player id, so the client's chat handler finds no name for it
        # and prints the text on its own -- which is what a server line wants. The
        # prefix is there because the text would otherwise read as a player's.
        # No "SERVER:" prefix: the client labels a speaker with no player row as
        # SERVER itself (0xFF matches no player), so a prefix would double it.
        for piece in _chat_chunks(rest):
            self.broadcast(m.CHAT.pack(0xFF, 0, 0, 0, piece), m.TAG["chat"])
        self.log.info("console: said %r" % rest)
        return "said to %d player(s)" % self.player_count()

    def cmd_kick(self, rest):
        parts = (rest or "").strip().split(None, 1)

        if not parts or not parts[0].isdigit():
            return "kick who?  (kick <id> [reason]; 'list' shows the ids)"

        return self.kick_player(int(parts[0]), parts[1] if len(parts) > 1 else None)

    @staticmethod
    def kick_text(by, reason):
        """The text a kicked player sees, cut to fit the KICK tail (NUL included)
        without splitting a UTF-8 character."""
        text = "Kicked by %s: %s" % (by, " ".join(str(reason).split()))
        raw = text.encode("utf-8")[:m.KICK_TEXT_LEN - 1]
        return raw.decode("utf-8", "ignore")

    def kick_player(self, pid, reason=None, by="admin", announce=True, rejoin=False):
        with self.lock:
            target = [(conn, c) for conn, c in self.clients.items() if c["id"] == pid]

        if not target:
            return "no player %d connected  ('list')" % pid

        conn, c = target[0]
        reason = " ".join(str(reason).split()) if reason else ""

        # The protocol already has this message, and the client handles it properly
        # ("You were kicked by the host" then out to the frontend) -- so send that
        # rather than just dropping the socket and leaving them guessing. With a
        # reason, the optional text tail replaces the stock line (old clients read
        # only the 4-byte head).
        # rejoin: KICK reserved[0] flag -- new clients reconnect on their own (and
        # keep their car); old ones just see the kick text.
        payload = m.KICK.pack(pid, m.KICK_FLAG_REJOIN if rejoin else 0, 0, 0)
        if reason:
            payload += self.kick_text(by, reason).encode("utf-8").ljust(m.KICK_TEXT_LEN, b"\0")
        try:
            self.send_to(conn, m.TAG["kick"], payload)
        except OSError:
            pass

        why = (" by %s: %s" % (by, reason)) if reason else ""
        self.log.info("kicked player %d '%s' (%s)%s" % (pid, c["name"], c["addr"], why))

        if reason and announce:
            try:
                self.send_server_chat("%s was kicked%s" % (c["name"], why))
            except Exception:
                pass

        try:
            # HALF-CLOSE, not SHUT_RDWR. The KICK frame is already in the socket;
            # SHUT_RDWR at this point can discard it, which is exactly the
            # "server switched city, rejoin" case the client never hears -- it
            # drops to the frontend instead of arming its auto-rejoin. Closing
            # the write side sends FIN after the KICK, so the peer reads the
            # frame first and then EOF. Same rule as _reject above.
            conn.shutdown(socket.SHUT_WR)
        except OSError:
            pass

        return "kicked player %d '%s'%s" % (pid, c["name"], (": " + reason) if reason else "")

    def cmd_beacon(self, rest):
        arg = (rest or "").strip().lower()

        if arg in ("on", "off"):
            self.beacon_on = (arg == "on")
            self.log.info("console: beacon %s" % arg)
            return "beacon %s" % arg

        if arg:
            return "usage: beacon [on|off]"

        return "beacon is %s (every %dms to UDP/%d)" % (
            "on" if self.beacon_on else "off", int(self.cfg["beacon_ms"]), m.DISCOVERY_PORT)

    def cmd_master(self, rest):
        if (rest or "").strip():
            return "usage: master"

        st = self.master_state

        if not st["base"]:
            return "no discovery server configured  (config 'master' is empty)"

        return "\n".join([
            "discovery:  %s" % st["base"],
            "registered: %s" % ("yes" if st["registered"] else "no"),
            "last:       %s" % (st["last"] or "-"),
            "heartbeat:  every %ss" % self.cfg["master_interval_s"],
        ])

    def cmd_stop(self, _rest):
        self.log.info("console: stop requested")
        self.stop.set()
        self.readvertise_evt.set()       # wake the master loop so it unregisters now
        return "stopping (unregisters from the master, closes players)..."

    def run(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind(("0.0.0.0", self.port))
        except OSError as e:
            self.log.error("could not bind TCP/%d: %s" % (self.port, e))
            return 1
        srv.listen(self.max_players)
        srv.settimeout(0.5)
        self.log.info("listening on TCP/%d (city %d, multiplayer map %d, up to %d players); Ctrl-C to stop"
                      % (self.port, self.city, self.arena, self.max_players))

        threads = []
        if self.cfg["beacon"]:
            threads.append(threading.Thread(target=self.beacon_loop, daemon=True))
        if self.cfg["master"]:
            threads.append(threading.Thread(target=self.master_loop, daemon=True))
        threads.append(threading.Thread(target=tick_loop, args=(self.plugins, self.stop),
                                        daemon=True))
        for t in threads:
            t.start()

        try:
            while not self.stop.is_set():
                try:
                    conn, addr = srv.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break
                threading.Thread(target=self.serve, args=(conn, addr), daemon=True).start()
        finally:
            self.stop.set()
            self.readvertise_evt.set()
            srv.close()
            self.plugins.unload()
            self.log.info("shutting down (uptime %.0fs, %d player(s))"
                          % (time.time() - self.started, self.player_count()))
        for t in threads:
            t.join(timeout=3)
        return 0


# ------------------------------------------------------------------------- main
def parse_args(argv):
    ap = argparse.ArgumentParser(description="headless dedicated server for the JERICHO mp mod")
    ap.add_argument("--config", default=None,
                    help="JSON config file (default: dediserver.json beside this script)")
    ap.add_argument("--port", type=int)
    ap.add_argument("--name")
    ap.add_argument("--city", type=int, help="GameLevel the clients load (0..3)")
    ap.add_argument("--arena", type=int,
                    help="which of the city's two multiplayer maps clients load (0 or 1; "
                         "the game's -mp 0 / -mp 1)")
    ap.add_argument("--gamemode", type=int)
    ap.add_argument("--max-players", type=int)
    ap.add_argument("--beacon", dest="beacon", action="store_true", default=None)
    ap.add_argument("--no-beacon", dest="beacon", action="store_false")
    ap.add_argument("--beacon-ms", type=int)
    ap.add_argument("--idle-drop", type=float, dest="idle_drop_s", help="seconds of silence that drop a client (0 = never)")
    ap.add_argument("--cops", dest="cops", action="store_true", default=None,
                    help="police cars spawn (default)")
    ap.add_argument("--no-cops", dest="cops", action="store_false")
    ap.add_argument("--cop-difficulty", type=int, choices=(0, 1, 2), metavar="N",
                    help="cop difficulty 0..2 (default 1)")
    ap.add_argument("--cop-immunity", action="store_true", default=None,
                    help="cops exist but never come after anyone")
    ap.add_argument("--invulnerable", action="store_true", default=None,
                    help="cars take no damage")
    ap.add_argument("--time-of-day", choices=TIMES_OF_DAY, help="session time of day (default day)")
    ap.add_argument("--weather", choices=WEATHERS, help="session weather (default clear)")
    ap.add_argument("--log-level", choices=sorted(LEVELS))
    ap.add_argument("--log-file")
    ap.add_argument("--master", help="master discovery URL, e.g. http://host:8100 ('' disables)")
    ap.add_argument("--master-name", help="name to register with the master (default: --name)")
    ap.add_argument("--advertise-port", metavar="N", type=int,
                    help="the public port players dial, if the router remaps it (0 = this "
                         "server's own --port). Only needed when the forward is not 1:1")
    ap.add_argument("--advertise-host", metavar="HOST",
                    help="the address players reach this server on, if that is not the "
                         "address the master sees (a NAT'd server: your public IP or hostname). "
                         "The listing is unusable without it behind NAT")
    ap.add_argument("--master-interval", type=float, dest="master_interval_s")
    return ap.parse_args(argv)


RULE_KEYS = ("cops", "cop_difficulty", "cop_immunity", "invulnerable")


TIMES_OF_DAY = ("dawn", "day", "dusk", "night")      # engine order (0..3)
WEATHERS = ("clear", "rain", "wet")                   # engine order (0..2)


def _named_index(value, names, default):
    v = str(value).strip().lower()
    if v.isdigit() and int(v) < len(names):
        return int(v)
    return names.index(v) if v in names else default


def time_of_day_index(cfg):
    return _named_index(cfg.get("time_of_day", "day"), TIMES_OF_DAY, 1)


def weather_index(cfg):
    return _named_index(cfg.get("weather", "clear"), WEATHERS, 0)


def pack_rules(cops, invuln, diff, immune):
    """mp_proto.h MP_RULES_PACK: cops 0x1, invuln 0x2, difficulty << 2 (mask 0x3), immune 0x10."""
    return ((0x1 if cops else 0) | (0x2 if invuln else 0)
            | ((int(diff) & 0x3) << 2) | (0x10 if immune else 0))


def rules_text(packed):
    return "cops %s, difficulty %d, immunity %s, invulnerable %s" % (
        "on" if packed & 0x1 else "off", (packed >> 2) & 0x3,
        "on" if packed & 0x10 else "off", "on" if packed & 0x2 else "off")


def resolve_rules(cfg, file_keys):
    """Set cfg["rules"] (the packed int the wire uses) from the readable keys.

    An old config that carries "rules" and none of the readable keys is honoured
    as-is; returns True then, so the caller can log a deprecation line."""
    legacy = ("rules" in file_keys and not any(k in file_keys for k in RULE_KEYS)
              and True)
    if legacy:
        cfg["rules"] = int(cfg["rules"]) & 0x1F
        return True
    diff = int(cfg.get("cop_difficulty", 1))
    if diff < 0 or diff > 2:
        diff = 1
    cfg["cop_difficulty"] = diff
    cfg["rules"] = pack_rules(cfg.get("cops", True), cfg.get("invulnerable", False),
                              diff, cfg.get("cop_immunity", False))
    return False


def _legacy_rule_skip(path):
    """A legacy file ("rules", none of the readable rule keys) is honoured as-is;
    adding the readable keys would silently replace it, so they are not added."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            keys = set(json.load(f))
    except (OSError, ValueError, TypeError):
        return ()
    if "rules" in keys and not any(k in keys for k in RULE_KEYS):
        return RULE_KEYS
    return ()


def build_config(argv):
    args = parse_args(argv)
    path = args.config
    if path is None:
        default_path = os.path.join(HERE, CONFIG_NAME)
        note = ensure_config(default_path, os.path.join(HERE, EXAMPLE_NAME))
        if note:
            print("[dedi] " + note, file=sys.stderr)
        path = default_path if os.path.exists(default_path) else ""
    if path:
        upgrade_config(path, DEFAULTS, skip=_legacy_rule_skip(path),
                       say=lambda msg: print("[dedi] " + msg, file=sys.stderr))
    cfg = load_config(path, DEFAULTS)
    apply_overrides(cfg, args, (
        ("port", "port"), ("name", "name"), ("city", "city"), ("arena", "arena"),
        ("gamemode", "gamemode"),
        ("max_players", "max_players"), ("beacon", "beacon"), ("beacon_ms", "beacon_ms"),
        ("idle_drop_s", "idle_drop_s"), ("cops", "cops"),
        ("cop_difficulty", "cop_difficulty"), ("cop_immunity", "cop_immunity"),
        ("invulnerable", "invulnerable"),
        ("time_of_day", "time_of_day"), ("weather", "weather"),
        ("log_level", "log_level"), ("log_file", "log_file"),
        ("master", "master"), ("master_name", "master_name"),
        ("advertise_host", "advertise_host"), ("advertise_port", "advertise_port"),
        ("master_interval_s", "master_interval_s"),
    ))
    file_keys = set()
    if path:
        with open(path, "r", encoding="utf-8") as f:
            file_keys = set(json.load(f))
    if any(getattr(args, k, None) is not None for k in RULE_KEYS):
        file_keys |= {"cops"}      # a rules flag on the command line wins over a legacy int
    cfg["_rules_legacy"] = resolve_rules(cfg, file_keys)
    return cfg, path


def main(argv=None):
    cfg, path = build_config(argv)
    log = Log(cfg.get("log_level", "info"), cfg.get("log_file", ""))
    if path:
        log.debug("config: %s" % path)
    proto_check.assert_ok()
    if cfg.pop("_rules_legacy", False):
        log.warning("config: \"rules\": %d is deprecated -- use \"cops\", \"cop_difficulty\", "
                    "\"cop_immunity\", \"invulnerable\" (%s)" % (cfg["rules"], rules_text(cfg["rules"])))
    log.info("rules: %s" % rules_text(int(cfg["rules"])))

    # -- the values that would otherwise fail quietly
    cleaned = normalise_host(cfg["advertise_host"])

    if cleaned != (cfg["advertise_host"] or ""):
        log.warning("advertise_host %r -> %r (a scheme, path or port cannot be part "
                    "of a host; the port has its own key)"
                    % (cfg["advertise_host"], cleaned))
        cfg["advertise_host"] = cleaned

    # The listing's name comes from the wire's 32-byte field, and the master
    # refuses anything outside 1..31 rather than truncating it itself -- so a long
    # name costs the WHOLE registration (a 400 the log calls "master unreachable"),
    # which reads like a network fault and is not one.
    name = str(cfg["name"] or "")

    if not (1 <= len(name) <= 31):
        trimmed = (name.strip() or "JERICHO Server")[:31]
        log.warning("name %r is %d characters; a listing's name is 1..31 (the wire "
                    "field is 32 bytes with its terminator) and the master rejects the "
                    "whole registration outside that, so it will be listed as %r"
                    % (name, len(name), trimmed))
        cfg["name"] = trimmed

    if int(cfg["max_players"]) > m.MAX_PLAYERS:
        log.warning("max_players %d is above the protocol's %d -- a player's slot is a "
                    "number in MP_MAX_PLAYERS' range, and the client's roster holds %d, "
                    "so the extra seats could not be used; using %d"
                    % (int(cfg["max_players"]), m.MAX_PLAYERS, m.MAX_PLAYERS, m.MAX_PLAYERS))
        cfg["max_players"] = m.MAX_PLAYERS

    if int(cfg["city"]) < 0 or int(cfg["city"]) > 3:
        log.warning("city %d is outside 0..3 (CHICAGO, HAVANA, LAS VEGAS, RIO); the "
                    "clients will load whatever it names, if the level registry has it"
                    % int(cfg["city"]))

    mode = str(cfg.get("map_mode", MAP_MODE_MP)).strip().lower()
    if mode not in (MAP_MODE_CITY, MAP_MODE_MP):
        log.warning("map_mode %r is not city or mp; using mp" % mode)
        mode = MAP_MODE_MP
    cfg["map_mode"] = mode
    arena = int(cfg["arena"])
    if arena not in (0, 1):
        log.warning("arena %d is not 0 or 1 (the two multiplayer maps of a city); "
                    "using 0" % arena)
        arena = 0
    cfg["arena"] = arena

    for key, names, idx in (("time_of_day", TIMES_OF_DAY, time_of_day_index),
                            ("weather", WEATHERS, weather_index)):
        if _named_index(cfg[key], names, -1) < 0:
            log.warning("%s %r is not one of %s; using %s"
                        % (key, cfg[key], "/".join(names), names[idx(cfg)]))
        cfg[key] = names[idx(cfg)]

    cfg["_config_path"] = path
    server = Dedicated(cfg, log)

    log.debug("signals: %s" % ", ".join(install_signals(server.stop, log)))

    console = Console(log, server.console_commands())
    server.console = console
    console.start()

    return server.run()

